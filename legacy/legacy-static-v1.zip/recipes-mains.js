/* ---------------- CHICKEN, MEAT & FISH ---------------- */
RECIPES.push(
{
  id: 'sheet-pan-chicken',
  title: 'Sheet-Pan Chicken & Vegetables',
  blurb: 'Crispy chicken, roasted potatoes, charred broccoli. One tray, almost no washing up.',
  cat: 'meat', serves: 4, time: 40,
  tags: ['high-protein', 'one-pan'],
  ing: [
    { k: 'chicken', q: 700, u: 'g', n: 'chicken thighs' },
    { k: 'potato', q: 600, u: 'g', n: 'baby potatoes' },
    { k: 'broccoli', q: 1, u: '', n: 'head of broccoli' },
    { k: 'garlic', q: 4, u: 'clove' },
    { k: 'lemon', q: 1, u: '' },
    { k: 'paprika', q: 1, u: 'tsp' },
    { k: 'olive oil', q: 3, u: 'tbsp', pantry: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Heat the oven to 220°C. Halve the potatoes and toss them on a large tray with 1 tbsp oil, salt and pepper. Roast for 15 min.',
    'Rub the chicken with the remaining oil, paprika, salt and pepper. Add to the tray skin-side up with the garlic cloves and lemon halves.',
    'Roast for 15 min, then add the broccoli florets tossed in the pan juices.',
    'Roast 10 min more, until the chicken is golden and cooked through and the broccoli has crispy tips.',
    'Squeeze the roasted lemon over everything before serving.'
  ],
  tip: 'Do not crowd the tray. Vegetables steam when they touch; give them space for browned edges.'
},
{
  id: 'pan-chicken-garlic-butter',
  title: 'Pan Chicken with Garlic Butter',
  blurb: 'Golden chicken breasts in a glossy garlic pan sauce. 25 minutes.',
  cat: 'meat', serves: 2, time: 25,
  tags: ['high-protein', 'quick'],
  ing: [
    { k: 'chicken', q: 2, u: '', n: 'chicken breasts' },
    { k: 'butter', q: 2, u: 'tbsp' },
    { k: 'garlic', q: 3, u: 'clove' },
    { k: 'lemon', q: 0.5, u: '' },
    { k: 'parsley', q: 1, u: 'handful', opt: true },
    { k: 'olive oil', q: 1, u: 'tbsp', pantry: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Pat the chicken dry and season both sides well. If the breasts are thick, slice them horizontally into thinner cutlets so they cook evenly.',
    'Heat the oil in a pan over medium-high. Cook the chicken for 5 min a side without moving it, until golden.',
    'Lower the heat, add the butter and sliced garlic, and spoon the foaming butter over the chicken for 1 min.',
    'Squeeze in the lemon juice and add 2 tbsp water. Swirl to make a sauce.',
    'Rest the chicken for 3 min, then spoon over the sauce and parsley.'
  ],
  tip: 'Chicken is done at 74°C, but it is still juicy at 70°C after resting. If you do not have a thermometer, cut into the thickest part — no pink.'
},
{
  id: 'chicken-stir-fry',
  title: 'Sticky Chicken Stir-Fry',
  blurb: 'Sweet-salty chicken and peppers over rice. Faster than delivery.',
  cat: 'meat', serves: 3, time: 20,
  tags: ['high-protein', 'quick', 'one-pan'],
  ing: [
    { k: 'chicken', q: 500, u: 'g', n: 'chicken breast or thigh' },
    { k: 'bell pepper', q: 2, u: '', n: 'bell peppers' },
    { k: 'onion', q: 1, u: '', n: 'onion' },
    { k: 'garlic', q: 3, u: 'clove' },
    { k: 'ginger', q: 1, u: 'tbsp', n: 'ginger, grated' },
    { k: 'soy sauce', q: 3, u: 'tbsp' },
    { k: 'honey', q: 1, u: 'tbsp' },
    { k: 'rice', q: 1.5, u: 'cup', n: 'rice, to serve' },
    { k: 'oil', q: 2, u: 'tbsp', pantry: true }
  ],
  steps: [
    'Start the rice. Slice the chicken thinly against the grain and cut the peppers and onion into strips.',
    'Mix the soy sauce, honey and 3 tbsp water in a cup.',
    'Heat 1 tbsp oil in a wok or wide pan until very hot. Stir-fry the chicken for 3 min until just cooked. Remove.',
    'Add the rest of the oil, then the onion and peppers. Cook for 3 min, then add the garlic and ginger for 30 sec.',
    'Return the chicken, pour in the sauce, and toss for 1 min until sticky. Serve over rice.'
  ],
  tip: 'Freeze the chicken for 10 min before slicing — firm meat is much easier to cut thin.'
},
{
  id: 'beef-tacos',
  title: 'Weeknight Beef Tacos',
  blurb: 'Spiced beef, warm tortillas, cool salsa. Everyone builds their own.',
  cat: 'meat', serves: 4, time: 20,
  tags: ['high-protein', 'quick'],
  ing: [
    { k: 'beef', q: 500, u: 'g', n: 'ground beef' },
    { k: 'tortilla', q: 8, u: '', n: 'small tortillas' },
    { k: 'onion', q: 1, u: '', n: 'onion' },
    { k: 'garlic', q: 2, u: 'clove' },
    { k: 'cumin', q: 1, u: 'tsp' },
    { k: 'paprika', q: 1, u: 'tsp' },
    { k: 'cheese', q: 80, u: 'g', n: 'cheese, grated' },
    { k: 'salsa', q: 4, u: 'tbsp' },
    { k: 'lettuce', q: 0.5, u: '', n: 'lettuce', opt: true },
    { k: 'oil', q: 1, u: 'tbsp', pantry: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Heat the oil in a wide pan and cook the chopped onion for 3 min.',
    'Add the beef and cook over high heat for 5 min, breaking it up, until browned.',
    'Stir in the garlic, cumin and paprika plus 3 tbsp water. Simmer for 3 min until glossy.',
    'Warm the tortillas in a dry pan for 20 sec a side and stack them under a towel.',
    'Set everything out and let people build their own.'
  ],
  tip: 'The 3 tbsp of water at the end makes the beef saucy instead of crumbly. Do not skip it.'
},
{
  id: 'honey-garlic-salmon',
  title: 'Honey Garlic Salmon',
  blurb: 'Caramelised salmon with a sticky glaze, ready in 20 minutes.',
  cat: 'fish', serves: 2, time: 20,
  tags: ['pescatarian', 'high-protein', 'quick'],
  ing: [
    { k: 'salmon', q: 2, u: '', n: 'salmon fillets' },
    { k: 'honey', q: 1.5, u: 'tbsp' },
    { k: 'soy sauce', q: 2, u: 'tbsp' },
    { k: 'garlic', q: 3, u: 'clove' },
    { k: 'rice', q: 1, u: 'cup', n: 'rice, to serve' },
    { k: 'broccoli', q: 1, u: '', n: 'head of broccoli', opt: true },
    { k: 'sesame seeds', q: 1, u: 'tsp', opt: true },
    { k: 'oil', q: 1, u: 'tbsp', pantry: true }
  ],
  steps: [
    'Start the rice. Mix the honey, soy sauce, grated garlic and 2 tbsp water.',
    'Pat the salmon dry and season lightly with salt.',
    'Heat the oil in a non-stick pan over medium-high. Cook the salmon skin-side down for 3 min, then flip for 2 min.',
    'Pour in the glaze and spoon it over the salmon for 1–2 min until sticky. Keep the heat moderate — honey burns fast.',
    'Serve over rice with steamed broccoli and sesame seeds.'
  ],
  tip: 'Cook salmon skin-side down 80% of the time. The skin protects the flesh and turns wonderfully crisp.'
},
{
  id: 'chicken-noodle-soup',
  title: 'Chicken Noodle Soup',
  blurb: 'From-scratch comfort in 35 minutes. The cure for a grey day.',
  cat: 'soup', serves: 4, time: 35,
  tags: ['high-protein', 'comfort'],
  ing: [
    { k: 'chicken', q: 400, u: 'g', n: 'chicken breast or thigh' },
    { k: 'noodles', q: 150, u: 'g', n: 'egg noodles' },
    { k: 'carrot', q: 2, u: '' },
    { k: 'celery', q: 2, u: '' },
    { k: 'onion', q: 1, u: '', n: 'onion' },
    { k: 'garlic', q: 2, u: 'clove' },
    { k: 'stock', q: 1.5, u: 'l', n: 'stock' },
    { k: 'lemon', q: 0.5, u: '', opt: true },
    { k: 'parsley', q: 1, u: 'handful', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Dice the onion, carrot and celery. Warm a splash of oil in a pot and cook them for 5 min.',
    'Add the garlic and stock. Bring to a simmer.',
    'Add the chicken and poach gently for 15 min, until cooked through. Lift it out and shred with two forks.',
    'Add the noodles and cook for 5 min. Return the chicken.',
    'Season, then finish with lemon and parsley.'
  ],
  tip: 'Cook the noodles in the soup only if you are eating it all now. Otherwise cook them separately so they do not drink the broth.'
},
{
  id: 'garlic-butter-shrimp',
  title: 'Garlic Butter Shrimp',
  blurb: 'Sizzled shrimp with lemon and chilli. Serve with bread to mop the pan.',
  cat: 'fish', serves: 2, time: 15,
  tags: ['pescatarian', 'quick', 'high-protein'],
  ing: [
    { k: 'shrimp', q: 400, u: 'g', n: 'shrimp, peeled' },
    { k: 'butter', q: 3, u: 'tbsp' },
    { k: 'garlic', q: 5, u: 'clove' },
    { k: 'lemon', q: 1, u: '' },
    { k: 'chili flakes', q: 0.5, u: 'tsp', opt: true },
    { k: 'parsley', q: 1, u: 'handful', opt: true },
    { k: 'bread', q: 4, u: 'slice', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Pat the shrimp very dry and season with salt.',
    'Melt half the butter in a large pan over high heat until foaming.',
    'Add the shrimp in one layer and cook for 1 min. Flip, add the garlic and chilli, and cook 1 min more.',
    'Add the remaining butter and a squeeze of lemon. Toss until the shrimp are just pink and the sauce is glossy.',
    'Scatter with parsley and serve with toasted bread.'
  ],
  tip: 'Shrimp are done the moment they curl into a loose C. A tight O means overcooked.'
},
{
  id: 'pork-chops-mustard-cream',
  title: 'Pork Chops with Mustard Cream',
  blurb: 'Juicy chops in a tangy pan sauce. Looks like a bistro plate, takes 30 minutes.',
  cat: 'meat', serves: 2, time: 30,
  tags: ['high-protein'],
  ing: [
    { k: 'pork', q: 2, u: '', n: 'pork chops' },
    { k: 'cream', q: 100, u: 'ml', n: 'cream' },
    { k: 'mustard', q: 1, u: 'tbsp' },
    { k: 'garlic', q: 2, u: 'clove' },
    { k: 'potato', q: 400, u: 'g', n: 'potatoes, to serve' },
    { k: 'butter', q: 1, u: 'tbsp' },
    { k: 'olive oil', q: 1, u: 'tbsp', pantry: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Boil the potatoes in salted water for 15 min while you cook the chops.',
    'Pat the chops dry, season well, and score the fat edge with a knife so they do not curl.',
    'Heat the oil in a pan over medium-high and cook the chops for 4–5 min a side, until golden and just cooked. Rest on a plate.',
    'Lower the heat, melt the butter, add the garlic for 30 sec, then the cream and mustard. Simmer for 2 min, scraping the pan.',
    'Season the sauce, spoon over the chops, and serve with the potatoes.'
  ],
  tip: 'Pork chops dry out fast. Take them off at 63°C and rest — they will come up to temperature on the plate.'
}
);
