# Recipe Scaler Whisperer

A tiny cooking app that answers one question: **what can I cook right now?**

Type what's actually in your kitchen — `3 eggs`, `half an onion`, `400g canned tomatoes` — set how much time you have, and it shows only recipes that genuinely work with what you've got. Every recipe scales its quantities to the number of people you're feeding.

No account, no API key. 48 recipes, all bundled. Installed from a permanent HTTPS link, it works offline.

---

## Run it on this Mac

1. Double-click **`start.command`**.
   - If macOS blocks it: right-click → **Open** → **Open** once.
2. Your browser opens `http://localhost:4173`.
3. Leave the little Terminal window running while you use the app. Press `Ctrl+C` there to stop it.

Terminal-shy alternative:

```bash
cd /path/to/recipe-scaler-whisperer
python3 -m http.server 4173
```

Then open <http://localhost:4173>.

---

## Put it on your phone (same Wi-Fi)

`start.command` prints a second address like:

```
On your phone: http://192.168.1.24:4173
```

Type that into Safari (iPhone) or Chrome (Android) while both devices are on the same Wi-Fi.

**Add it to your home screen so it feels like a real app:**

- **iPhone / iPad:** open in **Safari** → Share button → **Add to Home Screen**.
- **Android:** open in **Chrome** → menu **⋮** → **Install app** (or **Add to Home screen**).

It launches full-screen and remembers your basket, saved recipes and shopping list. On the permanent HTTPS URL it also keeps working offline once it has loaded once.

> The local Wi-Fi address is for trying it while your Mac is awake. Browsers only allow offline caching and proper app install on HTTPS, so use the permanent URL below for daily phone use.

---

## Make it permanent (optional)

The app is a plain static site — any free static host works.

**Netlify Drop (easiest, no account needed to try):**
1. Go to <https://app.netlify.com/drop>.
2. Drag the whole app folder onto the page.
3. You get a URL like `https://your-random-name.netlify.app` that works anywhere, forever.

**GitHub Pages:** push the folder to a repo, then Settings → Pages → deploy from the main branch. All paths are relative, so it works from a subfolder too.

---

## How the matching works

- **Make now** is strict: every non-pantry ingredient must be in your basket, in a sufficient quantity.
- **Almost there** shows recipes missing up to 2 ingredients, so you can plan a quick shop.
- **Everything** is the full browse view, still filtered by your time limit and diet.
- **Pantry staples** (salt, pepper, oil, sugar, water by default) are assumed to be at home. You can tick more in **Your kitchen** — paprika, cumin, soy sauce, etc.
- Quantities are parsed, so `3 eggs`, `half an onion`, `2 cloves garlic`, `400 g canned tomatoes`, `1 cup rice` all work.
- Substitutions use broad keys: `parmesan` or `pecorino` both match `cheese`; `spring onions` or `scallions` both match `scallion`.

**Tips for best results:** use the quick-add chips for common staples, and add the *amount* when you know it. If a recipe says you're "a little short", it means you have the ingredient but not quite enough — lower the servings or add more.

---

## What's inside

- **48 curated recipes** across eggs, pasta, rice and grains, meat and fish, breakfast and soups, and small plates.
- **Servings scaler** on every recipe — quantities update instantly; cooking times stay the same (go by look and smell).
- **Cook mode** — one big step at a time, with built-in timers parsed from the instructions, a screen wake lock, and a swipe-free Next button.
- **Saved recipes** and a **shopping list** that collects missing ingredients per recipe.
- **Diet filters:** vegetarian, vegan, high protein, one pan.
- **Time filters:** 15, 30, 40, 60 minutes, or any time.
- **Offline-first PWA** — a service worker caches the app shell.
- **All data stays on your device** in `localStorage`.

---

## Files

| File | Purpose |
| --- | --- |
| `index.html` | App shell and icon sprite |
| `styles.css` | All styling (mobile-first, warm editorial look) |
| `data-core.js` | Ingredient aliases, pantry staples, category metadata |
| `recipes-eggs.js`, `recipes-pasta.js`, `recipes-rice.js`, `recipes-mains.js`, `recipes-veg1.js`, `recipes-veg2.js` | The recipe database |
| `app.js` | Parsing, matching, scaling, results rendering |
| `app-ui.js` | Detail sheet, saved/list/settings, cook mode, timers |
| `sw.js` | Offline cache |
| `manifest.webmanifest` | PWA metadata |
| `icon-192.png`, `icon-512.png` | App icons |
| `start.command` | Double-click local server |
| `gen_icons.py` | Regenerates the icons (optional) |
| `.test/` | Playwright smoke tests (optional, dev only) |

---

## Development notes

No build step, no dependencies, no framework. Edit any file and reload.

The test suite uses headless Chrome through `playwright-core`:

```bash
cd .test
npm install
node flow.js
```

`RECIPES.length` should be 48. The service worker cache name lives at the top of `sw.js`; bump it when you change cached assets so existing installs pick up the new version.

---

## Known limits

- The recipe set is deliberately small and curated, not a search engine.
- Matching is only as good as the ingredient names you type; common names and the quick-add chips work best.
- "Almost there" allows at most 2 missing ingredients.
- Recipes are written for home cooks, not lab conditions — times are guidance, not guarantees.

Built for real kitchens. Go make dinner.
