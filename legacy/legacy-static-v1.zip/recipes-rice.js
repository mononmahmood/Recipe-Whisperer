/* ---------------- RICE, GRAINS & BEANS ---------------- */
RECIPES.push(
{
  id: 'one-pot-chicken-rice',
  title: 'One-Pot Chicken & Rice',
  blurb: 'Golden chicken thighs over fluffy rice. Comfort food with one pan to wash.',
  cat: 'rice', serves: 4, time: 40,
  tags: ['high-protein', 'one-pan'],
  ing: [
    { k: 'chicken', q: 600, u: 'g', n: 'chicken thighs' },
    { k: 'rice', q: 2, u: 'cup', n: 'long-grain rice' },
    { k: 'stock', q: 3, u: 'cup' },
    { k: 'onion', q: 1, u: '', n: 'onion' },
    { k: 'garlic', q: 3, u: 'clove' },
    { k: 'paprika', q: 1, u: 'tsp' },
    { k: 'olive oil', q: 2, u: 'tbsp', pantry: true },
    { k: 'lemon', q: 0.5, u: '', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Season the chicken generously with salt, pepper and paprika. Heat the oil in a wide pot and brown the chicken skin-side down for 5 min. Set aside.',
    'Cook the chopped onion for 4 min in the same pot, then add the garlic for 30 sec.',
    'Stir in the rice and toast for 1 min. Pour in the stock and scrape the brown bits off the bottom.',
    'Nestle the chicken on top, cover, and cook on low for 18 min. Do not lift the lid.',
    'Turn off the heat and rest, covered, for 5 min. Fluff the rice and squeeze over lemon.'
  ],
  tip: 'Use a pot with a tight lid and resist peeking — every time you open it, you lose steam the rice needs.'
},
{
  id: 'coconut-chickpea-curry',
  title: 'Coconut Chickpea Curry',
  blurb: 'Creamy, spiced, and ready before the rice is. A pantry superhero.',
  cat: 'veg', serves: 4, time: 30,
  tags: ['vegan', 'one-pan'],
  ing: [
    { k: 'chickpea', q: 800, u: 'g', n: 'canned chickpeas' },
    { k: 'coconut milk', q: 400, u: 'ml' },
    { k: 'onion', q: 1, u: '', n: 'onion' },
    { k: 'garlic', q: 3, u: 'clove' },
    { k: 'ginger', q: 1, u: 'tbsp', n: 'ginger, grated' },
    { k: 'curry powder', q: 2, u: 'tbsp' },
    { k: 'spinach', q: 100, u: 'g', n: 'spinach', opt: true },
    { k: 'rice', q: 1.5, u: 'cup', n: 'rice, to serve', opt: true },
    { k: 'oil', q: 2, u: 'tbsp', pantry: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Warm the oil in a deep pan and cook the chopped onion for 5 min until soft.',
    'Add the garlic, ginger and curry powder. Stir for 1 min — the spices need this moment to wake up.',
    'Add the chickpeas (drained), coconut milk and 100 ml water. Simmer for 12 min.',
    'Crush a few chickpeas against the pan to thicken the sauce, then stir in the spinach until wilted.',
    'Taste for salt. Serve over rice with a squeeze of lemon if you have one.'
  ],
  tip: 'Curry powder varies wildly. Start with 1 tbsp, taste at the end, and add more if it tastes flat.'
},
{
  id: 'red-lentil-dal',
  title: 'Red Lentil Dal',
  blurb: 'Soft lentils, warm spices, coconut milk. Twenty minutes of hands-off simmering.',
  cat: 'veg', serves: 4, time: 30,
  tags: ['vegan', 'one-pan', 'comfort'],
  ing: [
    { k: 'lentil', q: 1.5, u: 'cup', n: 'red lentils' },
    { k: 'onion', q: 1, u: '', n: 'onion' },
    { k: 'garlic', q: 4, u: 'clove' },
    { k: 'ginger', q: 1, u: 'tbsp', n: 'ginger, grated' },
    { k: 'turmeric', q: 1, u: 'tsp' },
    { k: 'cumin', q: 1, u: 'tsp' },
    { k: 'coconut milk', q: 200, u: 'ml', opt: true },
    { k: 'lemon', q: 0.5, u: '', opt: true },
    { k: 'oil', q: 2, u: 'tbsp', pantry: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Rinse the lentils until the water runs clear.',
    'Warm the oil in a pot and cook the chopped onion for 5 min. Add the garlic, ginger, turmeric and cumin and stir for 1 min.',
    'Add the lentils, 4 cups water and 1 tsp salt. Bring to a boil, then simmer for 18 min until the lentils collapse.',
    'Stir in the coconut milk and warm through. Add more water if it is thicker than you like.',
    'Finish with a squeeze of lemon. Taste and add salt until it sings.'
  ],
  tip: 'The lemon at the end is not optional in spirit — acid is what makes lentils taste bright instead of muddy.'
},
{
  id: 'vegetable-stir-fry',
  title: 'Crunchy Vegetable Stir-Fry',
  blurb: 'Colourful veg, sticky soy-ginger sauce, rice. Better than the takeaway menu.',
  cat: 'veg', serves: 3, time: 25,
  tags: ['vegan', 'quick', 'one-pan'],
  ing: [
    { k: 'rice', q: 1.5, u: 'cup', n: 'rice' },
    { k: 'broccoli', q: 1, u: '', n: 'head of broccoli' },
    { k: 'bell pepper', q: 2, u: '', n: 'bell peppers' },
    { k: 'carrot', q: 2, u: '' },
    { k: 'garlic', q: 3, u: 'clove' },
    { k: 'ginger', q: 1, u: 'tbsp', n: 'ginger, grated' },
    { k: 'soy sauce', q: 3, u: 'tbsp' },
    { k: 'honey', q: 1, u: 'tbsp', opt: true },
    { k: 'oil', q: 2, u: 'tbsp', pantry: true }
  ],
  steps: [
    'Start the rice. Cut all the veg into similar-sized pieces so they cook evenly.',
    'Heat the oil in the widest pan you have until it shimmers. Add the broccoli and carrot and stir-fry for 3 min.',
    'Add the peppers and cook 2 min more. You want charred edges and crunch, not soft veg.',
    'Push the veg to the side, add the garlic and ginger, and stir for 30 sec.',
    'Add the soy sauce, honey and 2 tbsp water. Toss for 1 min until glossy. Serve over rice.'
  ],
  tip: 'A hot pan is everything. If the veg steams instead of sizzling, turn the heat up and cook in two batches.'
},
{
  id: 'garlic-shrimp-rice',
  title: 'Garlic Butter Shrimp & Rice',
  blurb: 'Juicy shrimp, garlic butter, lemon. A 25-minute dinner that feels fancy.',
  cat: 'fish', serves: 2, time: 25,
  tags: ['pescatarian', 'high-protein', 'one-pan'],
  ing: [
    { k: 'shrimp', q: 400, u: 'g', n: 'shrimp, peeled' },
    { k: 'rice', q: 1, u: 'cup', n: 'rice' },
    { k: 'butter', q: 2, u: 'tbsp' },
    { k: 'garlic', q: 4, u: 'clove' },
    { k: 'lemon', q: 1, u: '' },
    { k: 'peas', q: 0.5, u: 'cup', n: 'frozen peas', opt: true },
    { k: 'parsley', q: 1, u: 'handful', opt: true },
    { k: 'olive oil', q: 1, u: 'tbsp', pantry: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Cook the rice. Add the peas for the last 2 min if using.',
    'Pat the shrimp very dry with paper towel and season with salt and pepper.',
    'Heat the olive oil in a large pan over high heat. Cook the shrimp for 1 min per side, then remove to a plate.',
    'Lower the heat, melt the butter, and cook the sliced garlic for 30 sec. Add the lemon zest and juice.',
    'Return the shrimp for 30 sec, toss with the rice, and finish with parsley.'
  ],
  tip: 'Dry shrimp = golden shrimp. Wet shrimp steam and stay rubbery. Also pull them off the heat a touch early.'
},
{
  id: 'tuna-rice-bowl',
  title: 'Spicy Tuna Rice Bowl',
  blurb: 'Ten minutes, no cooking if your rice is ready. A desk-lunch upgrade.',
  cat: 'fish', serves: 1, time: 10,
  tags: ['pescatarian', 'quick', 'high-protein'],
  ing: [
    { k: 'tuna', q: 1, u: 'can', n: 'canned tuna' },
    { k: 'rice', q: 1, u: 'cup', n: 'cooked rice' },
    { k: 'mayo', q: 2, u: 'tbsp' },
    { k: 'hot sauce', q: 1, u: 'tsp' },
    { k: 'cucumber', q: 0.5, u: '', n: 'cucumber' },
    { k: 'nori', q: 1, u: 'sheet', n: 'nori sheet', opt: true },
    { k: 'sesame oil', q: 1, u: 'tsp', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Warm the rice (microwave with a splash of water and a plate on top works fine).',
    'Drain the tuna well, then mix with mayo, hot sauce and a pinch of salt.',
    'Slice the cucumber thinly.',
    'Pile the rice in a bowl, spoon the tuna on top, and add the cucumber.',
    'Finish with torn nori and a drizzle of sesame oil.'
  ],
  tip: 'Drain the tuna properly — watery tuna makes a sad, loose bowl. Press it against the lid of the can.'
},
{
  id: 'mujadara',
  title: 'Mujadara',
  blurb: 'Lentils, rice and a mountain of crispy onions. Humble food that tastes luxurious.',
  cat: 'rice', serves: 4, time: 45,
  tags: ['vegan', 'comfort'],
  ing: [
    { k: 'lentil', q: 1, u: 'cup', n: 'brown or green lentils' },
    { k: 'rice', q: 1, u: 'cup', n: 'long-grain rice' },
    { k: 'onion', q: 2, u: '', n: 'onions' },
    { k: 'cumin', q: 1.5, u: 'tsp' },
    { k: 'olive oil', q: 4, u: 'tbsp', pantry: true },
    { k: 'yogurt', q: 0.5, u: 'cup', n: 'yogurt, to serve', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Rinse the lentils. Simmer in 3 cups water for 15 min, until almost tender but not mushy. Drain, keeping the liquid.',
    'Thinly slice the onions. Heat the olive oil in a wide pan and fry them slowly for 15 min, stirring often, until deep brown and crispy. Scoop half onto paper towel.',
    'Add the cumin to the pan with the remaining onions and stir for 30 sec.',
    'Add the rice and lentils, 2 cups of the lentil water and 1 tsp salt. Bring to a boil, cover, and cook on low for 15 min.',
    'Rest covered for 5 min, fluff, and top with the crispy onions. Serve with yogurt.'
  ],
  tip: 'The crispy onions are the point. Cook them low and slow — if they go dark in 3 minutes, the heat is too high.'
},
{
  id: 'bean-cheese-burrito',
  title: 'Bean & Cheese Burrito',
  blurb: 'Ten-minute lunch with a crunchy toasted shell. Cheaper than a sandwich.',
  cat: 'rice', serves: 2, time: 10,
  tags: ['vegetarian', 'quick'],
  ing: [
    { k: 'tortilla', q: 2, u: '', n: 'large tortillas' },
    { k: 'beans', q: 400, u: 'g', n: 'black beans' },
    { k: 'cheese', q: 80, u: 'g', n: 'cheese, grated' },
    { k: 'salsa', q: 4, u: 'tbsp' },
    { k: 'rice', q: 0.5, u: 'cup', n: 'cooked rice', opt: true },
    { k: 'avocado', q: 1, u: '', n: 'avocado', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Drain and rinse the beans. Mash about half of them roughly with a fork and a pinch of salt.',
    'Warm the tortillas in a dry pan for 20 sec a side.',
    'Layer beans, rice, cheese and salsa down the middle, leaving a 3 cm border.',
    'Fold in the sides, then roll tightly from the bottom. Press the seam down.',
    'Toast seam-side down in the hot pan for 2 min a side until crisp and melty.'
  ],
  tip: 'Do not overfill. A tight roll with less filling toasts evenly; an overstuffed burrito explodes.'
},
{
  id: 'sausage-white-bean-skillet',
  title: 'Sausage & White Bean Skillet',
  blurb: 'Crispy sausage, creamy beans, wilted greens. A 25-minute one-pan wonder.',
  cat: 'meat', serves: 3, time: 25,
  tags: ['high-protein', 'one-pan'],
  ing: [
    { k: 'sausage', q: 400, u: 'g', n: 'sausages' },
    { k: 'beans', q: 400, u: 'g', n: 'cannellini beans' },
    { k: 'tomato-canned', q: 200, u: 'g', n: 'canned tomatoes' },
    { k: 'garlic', q: 3, u: 'clove' },
    { k: 'spinach', q: 100, u: 'g', n: 'spinach' },
    { k: 'olive oil', q: 1, u: 'tbsp', pantry: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Slice the sausages into thick coins. Heat the oil in a large pan and brown them for 6 min.',
    'Add the sliced garlic and cook for 30 sec, then pour in the tomatoes.',
    'Add the drained beans and simmer for 8 min, crushing a few beans to thicken the sauce.',
    'Stir in the spinach until wilted. Season with salt and pepper.',
    'Serve with bread, rice, or just a fork.'
  ],
  tip: 'Any sausage works — spicy, herby, even leftover roast chicken. Taste at the end and adjust the salt.'
},
{
  id: 'halloumi-couscous',
  title: 'Halloumi & Couscous Bowl',
  blurb: 'Squeaky golden halloumi, fluffy couscous, crunchy salad. Twenty minutes.',
  cat: 'veg', serves: 2, time: 20,
  tags: ['vegetarian', 'quick'],
  ing: [
    { k: 'couscous', q: 1, u: 'cup' },
    { k: 'halloumi', q: 200, u: 'g' },
    { k: 'tomato', q: 2, u: '', n: 'tomatoes' },
    { k: 'cucumber', q: 0.5, u: '', n: 'cucumber' },
    { k: 'lemon', q: 1, u: '' },
    { k: 'olive oil', q: 3, u: 'tbsp', pantry: true },
    { k: 'mint', q: 1, u: 'handful', n: 'mint or parsley', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Put the couscous in a bowl with a pinch of salt. Pour over 1 cup boiling water, cover with a plate, and leave for 5 min.',
    'Dice the tomatoes and cucumber. Fork the couscous to fluff it, then fold in the veg, lemon juice and 2 tbsp olive oil.',
    'Cut the halloumi into 1 cm slices and pat dry.',
    'Heat a dry non-stick pan over medium-high and fry the halloumi for 2 min a side until deeply golden.',
    'Pile the halloumi on the couscous, grind over pepper, and scatter with herbs.'
  ],
  tip: 'Halloumi is already salty, so season the couscous lightly. A dry pan gives the crispest crust.'
}
);
