/* ============================================================
   RECIPE SCALER WHISPERER — core data
   ============================================================ */

const RECIPES = [];

/* Ingredient keys are deliberately broad so "chicken breast"
   still matches a recipe that asks for chicken thighs. */
const ALIASES = {
  // eggs & dairy
  egg: 'egg', eggs: 'egg', 'large egg': 'egg', 'large eggs': 'egg',
  butter: 'butter', 'salted butter': 'butter', 'unsalted butter': 'butter',
  milk: 'milk', 'whole milk': 'milk', 'oat milk': 'milk', 'almond milk': 'milk',
  cream: 'cream', 'heavy cream': 'cream', 'double cream': 'cream', 'half and half': 'cream',
  yogurt: 'yogurt', yoghurt: 'yogurt', 'greek yogurt': 'yogurt', 'greek yoghurt': 'yogurt',
  cheese: 'cheese', cheddar: 'cheese', mozzarella: 'cheese', parmesan: 'cheese',
  pecorino: 'cheese', gruyere: 'cheese', 'cream cheese': 'cream cheese',
  feta: 'feta', halloumi: 'halloumi',

  // produce
  onion: 'onion', onions: 'onion', 'red onion': 'onion', 'yellow onion': 'onion', 'brown onion': 'onion',
  garlic: 'garlic', 'garlic clove': 'garlic', 'garlic cloves': 'garlic',
  tomato: 'tomato', tomatoes: 'tomato', 'cherry tomato': 'tomato', 'cherry tomatoes': 'tomato',
  'canned tomato': 'tomato-canned', 'canned tomatoes': 'tomato-canned',
  'tinned tomato': 'tomato-canned', 'tinned tomatoes': 'tomato-canned',
  passata: 'tomato-canned', 'crushed tomatoes': 'tomato-canned', 'diced tomatoes': 'tomato-canned',
  'tomato paste': 'tomato paste',
  potato: 'potato', potatoes: 'potato', 'baby potatoes': 'potato',
  'sweet potato': 'sweet potato', 'sweet potatoes': 'sweet potato',
  carrot: 'carrot', carrots: 'carrot', celery: 'celery', 'celery stalk': 'celery',
  cucumber: 'cucumber', cucumbers: 'cucumber',
  avocado: 'avocado', avocados: 'avocado',
  spinach: 'spinach', 'baby spinach': 'spinach',
  broccoli: 'broccoli', 'broccoli head': 'broccoli',
  mushroom: 'mushroom', mushrooms: 'mushroom', 'button mushrooms': 'mushroom',
  'bell pepper': 'bell pepper', 'bell peppers': 'bell pepper', peppers: 'bell pepper',
  capsicum: 'bell pepper', 'red pepper': 'bell pepper',
  scallion: 'scallion', scallions: 'scallion', 'green onion': 'scallion',
  'green onions': 'scallion', 'spring onion': 'scallion', 'spring onions': 'scallion',
  cilantro: 'cilantro', coriander: 'cilantro', 'fresh coriander': 'cilantro',
  parsley: 'parsley', basil: 'basil', mint: 'mint', dill: 'dill',
  lemon: 'lemon', lemons: 'lemon', lime: 'lime', limes: 'lime',
  ginger: 'ginger', 'fresh ginger': 'ginger',
  lettuce: 'lettuce', 'iceberg lettuce': 'lettuce', 'romaine': 'lettuce',
  corn: 'corn', 'sweetcorn': 'corn', peas: 'peas', 'frozen peas': 'peas',
  banana: 'banana', bananas: 'banana', berries: 'berries', strawberry: 'berries',
  strawberries: 'berries', blueberry: 'berries', blueberries: 'berries',

  // proteins
  chicken: 'chicken', 'chicken breast': 'chicken', 'chicken breasts': 'chicken',
  'chicken thigh': 'chicken', 'chicken thighs': 'chicken',
  beef: 'beef', 'ground beef': 'beef', mince: 'beef', 'minced beef': 'beef',
  pork: 'pork', 'pork chop': 'pork', 'pork chops': 'pork',
  sausage: 'sausage', sausages: 'sausage', chorizo: 'sausage',
  bacon: 'bacon', pancetta: 'bacon',
  shrimp: 'shrimp', prawns: 'shrimp', prawn: 'shrimp',
  salmon: 'salmon', 'salmon fillet': 'salmon', 'salmon fillets': 'salmon',
  tuna: 'tuna', 'canned tuna': 'tuna', 'tinned tuna': 'tuna',
  tofu: 'tofu', 'firm tofu': 'tofu',
  chickpea: 'chickpea', chickpeas: 'chickpea', garbanzo: 'chickpea', 'garbanzo beans': 'chickpea',
  beans: 'beans', 'black beans': 'beans', 'cannellini beans': 'beans',
  'white beans': 'beans', 'kidney beans': 'beans', 'canned beans': 'beans',
  lentil: 'lentil', lentils: 'lentil', 'red lentils': 'lentil', 'red lentil': 'lentil',

  // grains & bread
  rice: 'rice', 'white rice': 'rice', 'jasmine rice': 'rice', 'basmati rice': 'rice',
  'cooked rice': 'rice', 'leftover rice': 'rice', 'day old rice': 'rice',
  pasta: 'pasta', spaghetti: 'pasta', penne: 'pasta', rigatoni: 'pasta',
  linguine: 'pasta', fusilli: 'pasta', orzo: 'pasta', macaroni: 'pasta',
  noodles: 'noodles', ramen: 'noodles', 'egg noodles': 'noodles', 'rice noodles': 'noodles',
  bread: 'bread', toast: 'bread', sourdough: 'bread', 'sandwich bread': 'bread',
  baguette: 'bread', 'bread roll': 'bread', buns: 'bread',
  tortilla: 'tortilla', tortillas: 'tortilla', wrap: 'tortilla', wraps: 'tortilla',
  pita: 'pita', pitas: 'pita', 'pita bread': 'pita',
  couscous: 'couscous', flour: 'flour', 'all purpose flour': 'flour', 'plain flour': 'flour',
  oats: 'oats', 'rolled oats': 'oats', 'oatmeal': 'oats',
  'baking powder': 'baking powder', 'baking soda': 'baking soda',
  chia: 'chia', 'chia seeds': 'chia', cornstarch: 'cornstarch', 'corn starch': 'cornstarch',

  // pantry & flavour
  'olive oil': 'olive oil', 'extra virgin olive oil': 'olive oil',
  oil: 'oil', 'cooking oil': 'oil', 'vegetable oil': 'oil', 'canola oil': 'oil',
  'sesame oil': 'sesame oil',
  salt: 'salt', 'sea salt': 'salt', 'kosher salt': 'salt',
  'black pepper': 'black pepper', pepper: 'black pepper', 'ground pepper': 'black pepper',
  'chili flakes': 'chili flakes', 'red pepper flakes': 'chili flakes', chili: 'chili flakes',
  'chilli flakes': 'chili flakes', 'chili powder': 'chili powder',
  paprika: 'paprika', 'smoked paprika': 'paprika',
  cumin: 'cumin', turmeric: 'turmeric', cinnamon: 'cinnamon',
  'curry powder': 'curry powder', 'garam masala': 'garam masala',
  honey: 'honey', sugar: 'sugar', 'brown sugar': 'sugar', maple: 'maple syrup', 'maple syrup': 'maple syrup',
  'soy sauce': 'soy sauce', soy: 'soy sauce', tamari: 'soy sauce',
  'fish sauce': 'fish sauce', mustard: 'mustard', ketchup: 'ketchup',
  mayo: 'mayo', mayonnaise: 'mayo', sriracha: 'hot sauce', 'hot sauce': 'hot sauce',
  salsa: 'salsa', pesto: 'pesto', 'tomato sauce': 'tomato sauce',
  'coconut milk': 'coconut milk', 'coconut cream': 'coconut milk',
  stock: 'stock', broth: 'stock', 'chicken stock': 'stock', 'chicken broth': 'stock',
  'vegetable stock': 'stock', 'veg stock': 'stock', bouillon: 'stock',
  miso: 'miso', nori: 'nori', 'seaweed': 'nori', 'sesame seeds': 'sesame seeds',
  water: 'water', 'ice water': 'water'
};

const DEFAULT_STAPLES = ['salt', 'black pepper', 'oil', 'olive oil', 'sugar', 'water'];

/* Optional staples people can tick on in Settings. */
const STAPLE_CHOICES = [
  ['salt', 'Salt'], ['black pepper', 'Black pepper'], ['oil', 'Neutral oil'],
  ['olive oil', 'Olive oil'], ['sugar', 'Sugar'], ['water', 'Water'],
  ['butter', 'Butter'], ['flour', 'Flour'], ['soy sauce', 'Soy sauce'],
  ['honey', 'Honey'], ['paprika', 'Paprika'], ['cumin', 'Cumin'],
  ['turmeric', 'Turmeric'], ['cinnamon', 'Cinnamon'], ['chili flakes', 'Chilli flakes'],
  ['curry powder', 'Curry powder'], ['stock', 'Stock cubes'], ['cornstarch', 'Cornflour'],
  ['baking powder', 'Baking powder'], ['mustard', 'Mustard'], ['mayo', 'Mayo'],
  ['hot sauce', 'Hot sauce'], ['sesame oil', 'Sesame oil'], ['vinegar', 'Vinegar']
];

const PERISHABLE = ['spinach', 'mushroom', 'avocado', 'tomato', 'bread', 'berries',
  'lettuce', 'cucumber', 'bell pepper', 'scallion', 'cilantro', 'parsley', 'basil',
  'lemon', 'lime', 'cream', 'yogurt', 'milk', 'cheese', 'chicken', 'beef', 'pork',
  'sausage', 'shrimp', 'salmon', 'tofu', 'eggs', 'egg'];

const SHORT_LABEL = {
  bread: 'bread', cheese: 'cheese', mushroom: 'mushrooms', spinach: 'spinach',
  tomato: 'tomatoes', 'bell pepper': 'peppers', avocado: 'avocado', lemon: 'lemon',
  lime: 'lime', cream: 'cream', yogurt: 'yogurt', milk: 'milk', scallion: 'spring onions',
  cilantro: 'coriander', parsley: 'parsley', basil: 'basil', chicken: 'chicken',
  beef: 'beef', pork: 'pork', sausage: 'sausages', shrimp: 'prawns', salmon: 'salmon',
  tofu: 'tofu', egg: 'eggs', feta: 'feta', halloumi: 'halloumi', berries: 'berries',
  lettuce: 'lettuce', cucumber: 'cucumber'
};

const CAT_META = {
  eggs:      { label: 'Eggs',      hue: '#E9A23B' },
  pasta:     { label: 'Pasta',     hue: '#C4643F' },
  rice:      { label: 'Rice & grains', hue: '#7E9C86' },
  meat:      { label: 'Chicken & meat', hue: '#A34B3E' },
  fish:      { label: 'Fish & seafood', hue: '#4C7C8A' },
  breakfast: { label: 'Breakfast', hue: '#D9A64E' },
  veg:       { label: 'Vegetarian', hue: '#5E7F5A' },
  soup:      { label: 'Soup & comfort', hue: '#B06A44' },
  snack:     { label: 'Small plates', hue: '#8C7B5A' }
};
