#!/usr/bin/env python3
"""Generate the app icons without any image library."""
import math
import struct
import zlib

GREEN = (31, 70, 54)
GREEN_LIGHT = (44, 90, 70)
CREAM = (250, 246, 236)
SAFFRON = (233, 162, 59)


def px(buf, w, h, x, y, color):
    if 0 <= x < w and 0 <= y < h:
        i = (y * w + x) * 4
        buf[i:i + 4] = bytes((*color, 255))


def draw_icon(size):
    w = h = size
    buf = bytearray(w * h * 4)
    scale = size / 512

    for y in range(h):
        for x in range(w):
            dx = (x - w / 2) / scale
            dy = (y - h / 2) / scale
            # soft background glow
            r = math.sqrt(dx * dx + dy * dy)
            base = GREEN if r > 250 else GREEN_LIGHT
            px(buf, w, h, x, y, base)

    cx, cy = 256 * scale, 300 * scale
    outer = 150 * scale
    inner = 118 * scale
    for y in range(h):
        for x in range(w):
            d = math.hypot(x - cx, y - cy)
            if inner <= d <= outer:
                # plate ring with a tiny highlight on top
                col = CREAM
                if y < cy - 100 * scale and -0.5 < (x - cx) / outer < 0.5:
                    col = (255, 252, 246)
                px(buf, w, h, x, y, col)

    # a small saffron sun inside the plate
    for y in range(h):
        for x in range(w):
            if math.hypot(x - cx, y - (cy + 6 * scale)) <= 34 * scale:
                px(buf, w, h, x, y, SAFFRON)

    # three wavy steam ribbons
    for index, sx in enumerate((198, 256, 314)):
        colour = CREAM if index != 1 else SAFFRON
        for yy in range(int(92 * scale), int(232 * scale)):
            sway = math.sin((yy / scale - 92) / 26.0 + index * 1.9) * 12 * scale
            centre = sx * scale + sway
            radius = 11 * scale
            for xx in range(int(centre - radius), int(centre + radius) + 1):
                if math.hypot(xx - centre, 0) <= radius:
                    px(buf, w, h, xx, yy, colour)

    raw = bytearray()
    for y in range(h):
        raw.append(0)
        raw.extend(buf[y * w * 4:(y + 1) * w * 4])

    def chunk(tag, data):
        return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', zlib.crc32(tag + data) & 0xffffffff)

    png = b'\x89PNG\r\n\x1a\n'
    png += chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0))
    png += chunk(b'IDAT', zlib.compress(bytes(raw), 9))
    png += chunk(b'IEND', b'')
    return png


for size in (512, 192):
    with open(f'icon-{size}.png', 'wb') as f:
        f.write(draw_icon(size))
    print(f'wrote icon-{size}.png')
