/* ---------------- EGGS & BREAKFAST ---------------- */
RECIPES.push(
{
  id: 'shakshuka',
  title: 'Shakshuka',
  blurb: 'Eggs poached in a smoky tomato pan sauce. One pan and bread for scooping.',
  cat: 'eggs', serves: 2, time: 30,
  tags: ['vegetarian', 'one-pan', 'brunch'],
  ing: [
    { k: 'olive oil', q: 2, u: 'tbsp', pantry: true },
    { k: 'onion', q: 1, u: '', n: 'onion' },
    { k: 'garlic', q: 3, u: 'clove' },
    { k: 'tomato-canned', q: 400, u: 'g', n: 'canned tomatoes' },
    { k: 'paprika', q: 1, u: 'tsp' },
    { k: 'cumin', q: 0.5, u: 'tsp' },
    { k: 'egg', q: 4, u: '', n: 'eggs' },
    { k: 'bread', q: 2, u: 'slice' },
    { k: 'feta', q: 50, u: 'g', opt: true },
    { k: 'parsley', q: 1, u: 'handful', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Warm the olive oil in a wide pan over medium heat. Slice the onion and cook for 6 min until soft and golden at the edges.',
    'Add the crushed garlic, paprika and cumin. Stir for 30 sec — it should smell amazing, not burn.',
    'Tip in the tomatoes, season with salt and pepper, and simmer for 10 min until thick enough to hold a spoon trail.',
    'Make 4 little wells with the back of a spoon and crack an egg into each. Cover and cook for 6–8 min, until whites are set but yolks still wobble.',
    'Crumble over feta and parsley. Serve straight from the pan with toasted bread.'
  ],
  tip: 'Crack each egg into a small cup first — one bad egg never ruins the whole pan. No feta? A spoon of yogurt on top is just as good.'
},
{
  id: 'soft-scramble',
  title: 'Soft Scrambled Eggs on Toast',
  blurb: 'Custardy, buttery eggs. The 10-minute breakfast that feels like a restaurant.',
  cat: 'breakfast', serves: 2, time: 10,
  tags: ['vegetarian', 'quick', 'brunch', 'high-protein'],
  ing: [
    { k: 'egg', q: 4, u: '', n: 'eggs' },
    { k: 'butter', q: 1.5, u: 'tbsp' },
    { k: 'bread', q: 2, u: 'slice' },
    { k: 'chives', q: 1, u: 'tbsp', n: 'chives', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Toast the bread so it is ready the moment the eggs are.',
    'Crack the eggs into a bowl, add a pinch of salt, and beat with a fork until fully combined.',
    'Melt the butter in a non-stick pan over LOW heat. Pour in the eggs and stir slowly with a spatula, pushing the curds in from the edges.',
    'After 3–4 min, when the eggs look like loose porridge, pull the pan off the heat. They keep cooking in the pan.',
    'Spoon onto toast, grind over pepper, and snip chives on top.'
  ],
  tip: 'Low heat is the whole trick. If the eggs start looking dry, take them off 30 seconds earlier than you think.'
},
{
  id: 'egg-fried-rice',
  title: 'Egg Fried Rice',
  blurb: 'Faster than takeaway, and the best use for leftover rice in the fridge.',
  cat: 'rice', serves: 2, time: 15,
  tags: ['vegetarian', 'quick', 'one-pan'],
  ing: [
    { k: 'rice', q: 3, u: 'cup', n: 'cooked cold rice' },
    { k: 'egg', q: 2, u: '', n: 'eggs' },
    { k: 'peas', q: 0.5, u: 'cup', n: 'frozen peas' },
    { k: 'scallion', q: 3, u: '', n: 'spring onions' },
    { k: 'garlic', q: 2, u: 'clove' },
    { k: 'soy sauce', q: 1.5, u: 'tbsp' },
    { k: 'sesame oil', q: 1, u: 'tsp', opt: true },
    { k: 'oil', q: 2, u: 'tbsp', pantry: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Get everything chopped and within arm’s reach. This cooks in minutes.',
    'Heat 1 tbsp oil in a big frying pan until shimmering. Beat the eggs, pour them in, and scramble for 30 sec. Tip onto a plate.',
    'Add the rest of the oil, the garlic and the white parts of the spring onions. Fry for 20 sec.',
    'Add the cold rice and peas. Press the rice down and let it sit for 30 sec at a time, then toss — you want hot rice with a few crispy bits, about 4 min.',
    'Return the eggs, splash in the soy sauce and sesame oil, toss once more. Taste, then top with the green onion tops.'
  ],
  tip: 'Cold, day-old rice is drier and fries instead of steaming. Fresh rice works if you spread it on a plate for 10 min first.'
},
{
  id: 'spanish-tortilla',
  title: 'Spanish Tortilla',
  blurb: 'A thick potato-and-onion omelette. Cheap, filling, great cold the next day.',
  cat: 'eggs', serves: 4, time: 35,
  tags: ['vegetarian', 'one-pan'],
  ing: [
    { k: 'potato', q: 500, u: 'g', n: 'waxy potatoes' },
    { k: 'onion', q: 1, u: '', n: 'onion' },
    { k: 'egg', q: 6, u: '', n: 'eggs' },
    { k: 'olive oil', q: 5, u: 'tbsp', pantry: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Peel the potatoes and cut into 1 cm slices. Thinly slice the onion.',
    'Warm the olive oil in a 23 cm non-stick pan over medium-low heat. Add potatoes and onion with a big pinch of salt. Cook gently for 15 min, turning now and then, until the potatoes are tender but not browned.',
    'Beat the eggs in a large bowl with salt and pepper. Drain the potatoes in a colander over a bowl, then fold them into the eggs. Rest for 5 min.',
    'Wipe the pan, add 1 tbsp of the reserved oil, and heat over medium. Pour in the mixture, spread flat, and cook for 4 min.',
    'Slide onto a plate, flip back into the pan, and cook 3–4 min more. The middle should still be a little soft. Rest 5 min before cutting.'
  ],
  tip: 'The flip: put a large plate over the pan, hold both firmly, and turn away from you. Confidence is 90% of it.'
},
{
  id: 'spinach-frittata',
  title: 'Spinach & Cheese Frittata',
  blurb: 'A fridge-cleanout frittata that reheats beautifully for lunch.',
  cat: 'eggs', serves: 4, time: 30,
  tags: ['vegetarian', 'one-pan', 'high-protein'],
  ing: [
    { k: 'egg', q: 8, u: '', n: 'eggs' },
    { k: 'spinach', q: 100, u: 'g', n: 'spinach' },
    { k: 'cheese', q: 60, u: 'g', n: 'cheese, grated' },
    { k: 'onion', q: 1, u: '', n: 'onion' },
    { k: 'olive oil', q: 2, u: 'tbsp', pantry: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Heat the grill to high. Beat the eggs with salt and pepper.',
    'Warm the olive oil in an oven-proof frying pan over medium heat. Cook the sliced onion for 5 min until soft.',
    'Add the spinach and stir for 1 min until just wilted. Pour over the eggs and scatter with cheese.',
    'Cook on the hob for 3 min until the edges set, then slide under the grill for 4–5 min until puffed and golden.',
    'Rest for 3 min, then cut into wedges.'
  ],
  tip: 'Any cheese, any greens, any cooked veg works. Just squeeze watery veg dry first so the frittata sets.'
},
{
  id: 'egg-drop-soup',
  title: '10-Minute Egg Drop Soup',
  blurb: 'Silky ribbons of egg in hot broth. The thing to make when you are tired.',
  cat: 'soup', serves: 2, time: 10,
  tags: ['vegetarian', 'quick', 'comfort'],
  ing: [
    { k: 'stock', q: 700, u: 'ml', n: 'stock' },
    { k: 'egg', q: 2, u: '', n: 'eggs' },
    { k: 'cornstarch', q: 1, u: 'tbsp' },
    { k: 'scallion', q: 2, u: '', n: 'spring onions' },
    { k: 'soy sauce', q: 1, u: 'tsp' },
    { k: 'sesame oil', q: 1, u: 'tsp', opt: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Bring the stock to a gentle simmer. Mix the cornstarch with 2 tbsp cold water and stir it in — the soup will thicken slightly.',
    'Beat the eggs in a cup with a fork.',
    'Turn the heat to low. Stir the soup in one direction while slowly pouring in the eggs — this makes the ribbons.',
    'Season with soy sauce and pepper. Ladle into bowls and finish with sliced spring onion and sesame oil.'
  ],
  tip: 'Do not boil hard after the eggs go in, or the ribbons turn into gravel. Low and slow.'
},
{
  id: 'breakfast-tacos',
  title: 'Crispy Breakfast Tacos',
  blurb: 'Soft eggs, melted cheese, hot salsa. Wrap-and-go food that beats a cereal bar.',
  cat: 'breakfast', serves: 2, time: 15,
  tags: ['vegetarian', 'quick', 'brunch'],
  ing: [
    { k: 'egg', q: 4, u: '', n: 'eggs' },
    { k: 'tortilla', q: 4, u: '', n: 'small tortillas' },
    { k: 'cheese', q: 60, u: 'g', n: 'cheese, grated' },
    { k: 'salsa', q: 4, u: 'tbsp' },
    { k: 'butter', q: 1, u: 'tbsp' },
    { k: 'avocado', q: 1, u: '', n: 'avocado', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Warm the tortillas in a dry pan for 20 sec a side, then wrap them in a clean tea towel so they stay soft.',
    'Beat the eggs with a pinch of salt. Melt the butter in the same pan over low heat and scramble gently for 3 min.',
    'Spoon eggs down the middle of each tortilla, add cheese, and fold.',
    'Return the tacos to the hot pan for 30 sec a side to crisp and melt the cheese.',
    'Top with salsa and sliced avocado.'
  ],
  tip: 'Keep the tortillas covered — cold tortillas crack when folded. This is the one rule.'
},
{
  id: 'avocado-egg-toast',
  title: 'Avocado & Egg Toast',
  blurb: 'Crunchy toast, smashed avocado, jammy egg. Ten minutes, zero regrets.',
  cat: 'breakfast', serves: 1, time: 10,
  tags: ['vegetarian', 'quick', 'brunch'],
  ing: [
    { k: 'bread', q: 2, u: 'slice' },
    { k: 'avocado', q: 1, u: '', n: 'ripe avocado' },
    { k: 'egg', q: 2, u: '', n: 'eggs' },
    { k: 'lemon', q: 0.5, u: '', n: 'lemon' },
    { k: 'chili flakes', q: 1, u: 'pinch', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Boil the eggs for 7 min, then run under cold water and peel. The yolks will be just set in the middle.',
    'Toast the bread while the eggs cook.',
    'Mash the avocado with a squeeze of lemon, salt and pepper. Spread thickly on the toast.',
    'Halve the eggs and lay them on top. Finish with chilli flakes and a little more salt.'
  ],
  tip: 'An avocado is ripe when the little stem nub pops off easily. Rock hard? Skip it and use butter and jammy eggs instead.'
}
);
