'use strict';

/* ============================================================
   layers
   ============================================================ */
let sideMode = 'saved';
let cookSteps = [];
let cookIdx = 0;
let cookReturnFocus = null;
let wakeLock = null;

function syncLock() {
  const open = document.querySelector('.sheet.is-open, .cook.is-open');
  document.body.classList.toggle('locked', !!open);
}

function openLayer(sheetSel, scrimSel) {
  lastFocus = document.activeElement;
  const sheet = $(sheetSel);
  sheet.classList.add('is-open');
  sheet.setAttribute('aria-hidden', 'false');
  if (scrimSel) $(scrimSel).classList.add('is-on');
  syncLock();
  setTimeout(() => {
    const close = sheet.querySelector('.sheet-top .icon-btn');
    if (close) close.focus();
  }, 70);
}

function closeLayer(sheetSel, scrimSel) {
  const sheet = $(sheetSel);
  sheet.classList.remove('is-open');
  sheet.setAttribute('aria-hidden', 'true');
  if (scrimSel) $(scrimSel).classList.remove('is-on');
  syncLock();
  if (lastFocus && document.contains(lastFocus)) {
    try { lastFocus.focus(); } catch (e) { /* noop */ }
  }
}

/* ============================================================
   recipe detail
   ============================================================ */
function openRecipe(id) {
  const recipe = RECIPE_BY_ID[id];
  if (!recipe) return;
  if ($('#sideSheet').classList.contains('is-open')) closeSide();
  currentRecipe = recipe;
  detailServings = clamp(state.target || recipe.serves, 1, 12);
  checkedIngs = new Set();
  renderSheet();
  openLayer('#recipeSheet', '#scrim');
}

function closeRecipe() {
  if (!$('#recipeSheet').classList.contains('is-open')) return;
  stopTimer();
  closeLayer('#recipeSheet', '#scrim');
  currentRecipe = null;
  checkedIngs = new Set();
}

function renderSheet() {
  const r = currentRecipe;
  if (!r) return;
  stopTimer();
  const cat = CAT_META[r.cat] || CAT_META.veg;
  const factor = detailServings / r.serves;
  const a = analyze(r, detailServings);
  const staples = new Set(state.staples);
  const saved = state.saved.includes(r.id);

  $('#sheetKicker').textContent = cat.label;
  const heart = $('#sheetHeart');
  heart.classList.toggle('is-on', saved);
  heart.setAttribute('aria-pressed', saved);
  heart.setAttribute('aria-label', `${saved ? 'Remove from saved' : 'Save'} ${r.title}`);

  const shortHTML = a.short.length ? `<div class="callout short">
    <strong>A little short.</strong> You've listed ${esc(amountText(a.short[0].have, a.short[0].haveU))} ${esc(a.short[0].ing.n || a.short[0].ing.k)};
    this needs ${esc(amountText(a.short[0].need, a.short[0].ing.u))} ${esc(itemLabel(a.short[0].ing, a.short[0].need))}.
    ${a.short.length > 1 ? ` Plus ${a.short.length - 1} more ingredient${a.short.length > 2 ? 's' : ''} a little short.` : ''}
    Add more, or lower the servings.
  </div>` : '';

  const missingHTML = a.missing.length ? `<div class="callout missing">
    <div><strong>You're missing ${a.missing.length} thing${a.missing.length > 1 ? 's' : ''}:</strong></div>
    <div class="miss-line">${a.missing.map(m => `<span class="miss-chip">${esc(m.n || m.k)}</span>`).join('')}</div>
    <button type="button" class="btn small primary" data-act="add-missing">Add to shopping list</button>
  </div>` : '';

  const ingRows = r.ing.map((ing, idx) => {
    const qty = ing.q != null ? ing.q * factor : null;
    const checked = checkedIngs.has(ing.k);
    const amt = amountText(qty, ing.u);
    const name = itemLabel(ing, qty);
    const tags = `${staples.has(ing.k) ? '<span class="ing-pantry">staple</span>' : ''}${ing.opt ? '<span class="ing-opt">optional</span>' : ''}`;
    return `<li>
      <button type="button" class="ing-row ${checked ? 'is-checked' : ''} ${staples.has(ing.k) ? 'is-pantry' : ''}"
        data-act="ing" data-key="${esc(ing.k)}" aria-pressed="${checked}" aria-label="Tick off ${esc(name)}">
        <span class="ing-check"><svg class="icon"><use href="#i-check"/></svg></span>
        <span class="ing-text">${amt ? `<strong>${esc(amt)}</strong> ` : ''}${esc(name)}${tags}</span>
      </button>
    </li>`;
  }).join('');

  const steps = r.steps.map((text, idx) => {
    const t = stepTimer(text);
    return `<li>${esc(text)}${t ? `<br><button type="button" class="timer-btn" data-act="timer" data-sec="${t.sec}" aria-label="${esc(t.label)}">
      <svg class="icon"><use href="#i-clock"/></svg><span>${esc(t.label)}</span></button>` : ''}</li>`;
  }).join('');

  $('#sheetBody').innerHTML = `
    <p class="detail-eyebrow" style="--cat:${cat.hue}">${esc(cat.label)}</p>
    <h2 class="detail-title" id="sheetTitle">${esc(r.title)}</h2>
    <p class="detail-blurb">${esc(r.blurb)}</p>
    <div class="detail-meta">
      <span class="meta-chip"><svg class="icon"><use href="#i-clock"/></svg>${r.time} min total</span>
      <span class="meta-chip"><svg class="icon"><use href="#i-basket"/></svg>${r.ing.filter(i => !i.opt).length} ingredients</span>
      <span class="meta-chip saffron">Serves ${r.serves} as written</span>
    </div>

    <div class="servings-box">
      <div class="label">
        <strong>Cooking for ${detailServings}</strong>
        <small>${factor === 1 ? 'The original quantities' : `${fmtQty(factor)}× the original recipe`}</small>
      </div>
      <div class="stepper" role="group" aria-label="Servings">
        <button type="button" data-act="serv" data-dir="-1" aria-label="Fewer servings" ${detailServings <= 1 ? 'disabled' : ''}>
          <svg class="icon"><use href="#i-minus"/></svg></button>
        <output aria-live="polite">${detailServings}</output>
        <button type="button" data-act="serv" data-dir="1" aria-label="More servings" ${detailServings >= 12 ? 'disabled' : ''}>
          <svg class="icon"><use href="#i-plus"/></svg></button>
      </div>
    </div>
    <p class="scale-note"><svg class="icon"><use href="#i-flame"/></svg> Quantities scale. Cooking times stay about the same — go by look and smell.</p>

    ${shortHTML}
    ${missingHTML}

    <h3 class="section-h">What you need <small>${detailServings === r.serves ? `serves ${detailServings}` : `scaled from ${r.serves}`}</small></h3>
    <ul class="ing-list">${ingRows}</ul>

    <h3 class="section-h">How to cook it <small>tap a timer to start</small></h3>
    <ol class="steps">${steps}</ol>

    <div class="tip-box">
      <h4><svg class="icon"><use href="#i-spark"/></svg> Whisperer's tip</h4>
      <p>${esc(r.tip)}</p>
    </div>

    <div class="detail-actions">
      ${a.missing.length ? '<button type="button" class="btn ghost-btn" data-act="add-missing">Add missing</button>' : ''}
      <button type="button" class="btn primary" data-act="cook"><svg class="icon"><use href="#i-play"/></svg> Start cooking</button>
    </div>`;

  $('#sheetBody').scrollTop = 0;
}

function onSheetClick(e) {
  const btn = e.target.closest('[data-act]');
  if (!btn || !currentRecipe) return;
  const act = btn.dataset.act;

  if (act === 'serv') {
    detailServings = clamp(detailServings + Number(btn.dataset.dir), 1, 12);
    renderSheet();
  } else if (act === 'ing') {
    const key = btn.dataset.key;
    if (checkedIngs.has(key)) checkedIngs.delete(key);
    else checkedIngs.add(key);
    const on = checkedIngs.has(key);
    btn.classList.toggle('is-checked', on);
    btn.setAttribute('aria-pressed', on);
  } else if (act === 'timer') {
    startTimer(Number(btn.dataset.sec), btn);
  } else if (act === 'add-missing') {
    const a = analyze(currentRecipe, detailServings);
    const added = addToShoppingList(a.missing, currentRecipe.title);
    if (added) {
      btn.disabled = true;
      btn.textContent = 'Added to list';
    }
  } else if (act === 'cook') {
    openCook();
  }
}

/* ============================================================
   side sheet: saved / shopping / settings
   ============================================================ */
function openSide(mode) {
  sideMode = mode;
  renderSide(false);
  openLayer('#sideSheet', '#sideScrim');
}

function closeSide() {
  if (!$('#sideSheet').classList.contains('is-open')) return;
  closeLayer('#sideSheet', '#sideScrim');
}

function renderSide(preserveScroll) {
  const body = $('#sideBody');
  const scrollTop = body.scrollTop;
  const titles = { saved: 'Saved', list: 'Shopping list', settings: 'Your kitchen' };
  $('#sideTitle').textContent = titles[sideMode] || 'Saved';

  if (sideMode === 'saved') {
    const saved = state.saved.map(id => RECIPE_BY_ID[id]).filter(Boolean);
    body.innerHTML = `<h2 class="side-title">Saved recipes</h2>
      <p class="side-sub">Your shortlist. Open one and the quantities still scale to your table.</p>
      ${saved.length ? `<div class="mini-list">${saved.map(r => `<div class="mini-card">
        <button type="button" class="mini-main" data-act="open-saved" data-id="${esc(r.id)}">
          <strong>${esc(r.title)}</strong>
          <small>${esc((CAT_META[r.cat] || CAT_META.veg).label)} · ${r.time} min · serves ${r.serves}</small>
        </button>
        <button type="button" class="mini-remove" data-act="unsave" data-id="${esc(r.id)}" aria-label="Remove ${esc(r.title)}">
          <svg class="icon"><use href="#i-trash"/></svg>
        </button>
      </div>`).join('')}</div>` : `<div class="side-empty">Nothing saved yet. Tap the little heart on any recipe.</div>`}
      <p class="side-sub" style="margin-top:20px;font-size:12px">Saved on this device only. No account needed.</p>`;
  }

  if (sideMode === 'list') {
    const unchecked = state.list.filter(x => !x.checked);
    const checked = state.list.filter(x => x.checked);
    body.innerHTML = `<h2 class="side-title">Shopping list</h2>
      <p class="side-sub">Every missing piece, collected. Check things off at the shop.</p>
      ${state.list.length ? `${unchecked.map(listRowHTML).join('')}${checked.map(listRowHTML).join('')}`
        : `<div class="side-empty">Your list is empty. Open an almost-there recipe and tap “Add to shopping list”.</div>`}
      <form class="add-item-row" id="manualItemForm">
        <input id="manualItem" type="text" placeholder="Add an item, e.g. eggs" aria-label="Add shopping list item" enterkeyhint="done" autocomplete="off">
        <button class="btn small primary" type="submit">Add</button>
      </form>
      <div class="list-tools">
        <small>${unchecked.length} to buy · ${checked.length} checked</small>
        <button type="button" class="btn small ghost-btn" data-act="clear-checked" ${checked.length ? '' : 'disabled'}>Clear checked</button>
      </div>`;
  }

  if (sideMode === 'settings') {
    body.innerHTML = `<h2 class="side-title">Your kitchen</h2>
      <p class="side-sub">Set it once, then never think about it again.</p>

      <div class="settings-group">
        <h3>Cooking for</h3>
        <p>Recipes open scaled to this many people. You can still change it inside each recipe.</p>
        <div class="servings-box" style="margin:0">
          <div class="label"><strong>${state.target} ${state.target === 1 ? 'person' : 'people'}</strong><small>default servings</small></div>
          <div class="stepper" role="group" aria-label="Default servings">
            <button type="button" data-act="target" data-dir="-1" aria-label="Fewer people" ${state.target <= 1 ? 'disabled' : ''}>
              <svg class="icon"><use href="#i-minus"/></svg></button>
            <output>${state.target}</output>
            <button type="button" data-act="target" data-dir="1" aria-label="More people" ${state.target >= 12 ? 'disabled' : ''}>
              <svg class="icon"><use href="#i-plus"/></svg></button>
          </div>
        </div>
      </div>

      <div class="settings-group">
        <h3>Pantry staples</h3>
        <p>I'll assume these are always in the cupboard. They never count as “missing”.</p>
        <div class="staple-grid">
          ${STAPLE_CHOICES.map(([key, label]) => {
            const on = state.staples.includes(key);
            return `<button type="button" class="staple-toggle ${on ? 'is-on' : ''}" data-act="staple" data-key="${esc(key)}" aria-pressed="${on}">
              <span class="tick"><svg class="icon"><use href="#i-check"/></svg></span>${esc(label)}
            </button>`;
          }).join('')}
        </div>
        <p style="margin-top:10px;font-size:11.5px">${state.staples.length} assumed · tick anything you usually have. Spices count.</p>
      </div>

      <div class="settings-group">
        <h3>Put it on your phone</h3>
        <p><strong>iPhone:</strong> open in Safari → Share → Add to Home Screen.<br>
        <strong>Android:</strong> open in Chrome → menu <strong>⋮</strong> → Install app.<br>
        Offline mode needs the permanent HTTPS link — the local Wi-Fi address only works while the Mac is running.</p>
      </div>

      <div class="settings-group" style="border-bottom:0">
        <h3>Your data</h3>
        <p>Your basket, saves and list live on this device. Nothing is sent anywhere.</p>
        <button type="button" class="danger-btn" data-act="reset">Reset this app</button>
      </div>
      <p style="font-size:11px;color:var(--muted);padding-bottom:20px">${RECIPES.length} recipes · built for real kitchens.</p>`;
  }

  if (preserveScroll) body.scrollTop = scrollTop;
}

function listRowHTML(item) {
  return `<div class="list-row ${item.checked ? 'is-checked' : ''}">
    <button type="button" class="list-check" data-act="check-item" data-id="${esc(item.id)}" aria-label="Check ${esc(item.name)}" aria-pressed="${item.checked}">
      <svg class="icon"><use href="#i-check"/></svg>
    </button>
    <div class="list-main">
      <div class="list-name">${esc(item.name)}</div>
      ${item.source ? `<div class="list-source">for ${esc(item.source)}</div>` : ''}
    </div>
    <button type="button" class="mini-remove" data-act="remove-item" data-id="${esc(item.id)}" aria-label="Remove ${esc(item.name)}">
      <svg class="icon"><use href="#i-trash"/></svg>
    </button>
  </div>`;
}

function onSideClick(e) {
  const btn = e.target.closest('[data-act]');
  if (!btn) return;
  const act = btn.dataset.act;

  if (act === 'open-saved') {
    const id = btn.dataset.id;
    closeSide();
    setTimeout(() => openRecipe(id), 80);
  } else if (act === 'unsave') {
    state.saved = state.saved.filter(id => id !== btn.dataset.id);
    render();
    renderSide(true);
    toast('Removed from saved');
  } else if (act === 'check-item') {
    const item = state.list.find(x => x.id === btn.dataset.id);
    if (item) {
      item.checked = !item.checked;
      save();
      renderBadges();
      renderSide(true);
    }
  } else if (act === 'remove-item') {
    state.list = state.list.filter(x => x.id !== btn.dataset.id);
    save();
    renderBadges();
    renderSide(true);
  } else if (act === 'clear-checked') {
    state.list = state.list.filter(x => !x.checked);
    save();
    renderBadges();
    renderSide(true);
  } else if (act === 'target') {
    state.target = clamp(state.target + Number(btn.dataset.dir), 1, 12);
    save();
    render();
    renderSide(true);
  } else if (act === 'staple') {
    const key = btn.dataset.key;
    if (state.staples.includes(key)) state.staples = state.staples.filter(k => k !== key);
    else state.staples.push(key);
    save();
    render();
    renderSide(true);
  } else if (act === 'reset') {
    const yes = window.confirm('Reset this app? Your basket, saved recipes and shopping list will be cleared.');
    if (yes) {
      try { localStorage.removeItem(LS_KEY); } catch (err) { /* noop */ }
      state = defaultState();
      closeSide();
      render();
      toast('Fresh start.');
    }
  }
}

/* ============================================================
   cooking mode
   ============================================================ */
function openCook() {
  if (!currentRecipe) return;
  cookSteps = currentRecipe.steps;
  cookIdx = 0;
  cookReturnFocus = document.activeElement;
  $('#cookOverlay').classList.add('is-open');
  $('#cookOverlay').setAttribute('aria-hidden', 'false');
  syncLock();
  renderCook();
  requestWakeLock();
  setTimeout(() => $('#cookClose').focus(), 80);
}

function closeCook() {
  const overlay = $('#cookOverlay');
  if (!overlay.classList.contains('is-open')) return;
  stopTimer();
  overlay.classList.remove('is-open');
  overlay.setAttribute('aria-hidden', 'true');
  syncLock();
  releaseWakeLock();
  if (cookReturnFocus && document.contains(cookReturnFocus)) {
    try { cookReturnFocus.focus(); } catch (e) { /* noop */ }
  }
}

function renderCook() {
  stopTimer();
  const total = cookSteps.length;
  $('#cookProgress').textContent = `Step ${cookIdx + 1} of ${total}`;
  $('#cookNum').textContent = String(cookIdx + 1).padStart(2, '0');
  $('#cookStep').textContent = cookSteps[cookIdx] || '';

  const timer = stepTimer(cookSteps[cookIdx] || '');
  const timerBtn = $('#cookTimer');
  if (timer) {
    timerBtn.hidden = false;
    timerBtn.dataset.sec = timer.sec;
    timerBtn.dataset.label = timer.label;
    timerBtn.classList.remove('running', 'done');
    timerBtn.querySelector('span').textContent = timer.label;
    timerBtn.disabled = false;
  } else {
    timerBtn.hidden = true;
    timerBtn.dataset.sec = '';
  }

  $('#cookPrev').disabled = cookIdx === 0;
  $('#cookNext').innerHTML = cookIdx === total - 1
    ? 'Finish <svg class="icon"><use href="#i-check"/></svg>'
    : 'Next <svg class="icon"><use href="#i-right"/></svg>';

  const factor = detailServings / currentRecipe.serves;
  $('#cookIngredients').innerHTML = currentRecipe.ing.map(ing => {
    const q = ing.q != null ? ing.q * factor : null;
    const amt = amountText(q, ing.u);
    return `<div>${amt ? `<b>${esc(amt)}</b> ` : ''}${esc(itemLabel(ing, q))}${ing.opt ? ' <span style="opacity:.55">(optional)</span>' : ''}</div>`;
  }).join('');
}

function cookNext() {
  if (cookIdx >= cookSteps.length - 1) {
    closeCook();
    toast("Dinner's ready. Go eat.");
    return;
  }
  cookIdx++;
  renderCook();
}

/* ============================================================
   timers
   ============================================================ */
let audioCtx = null;

function initAudio() {
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === 'suspended') audioCtx.resume();
  } catch (e) { audioCtx = null; }
}

function beep() {
  if (!audioCtx) return;
  const now = audioCtx.currentTime;
  [0, 0.2, 0.4].forEach(offset => {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'sine';
    osc.frequency.value = 880;
    gain.gain.setValueAtTime(0.0001, now + offset);
    gain.gain.exponentialRampToValueAtTime(0.22, now + offset + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + offset + 0.15);
    osc.connect(gain).connect(audioCtx.destination);
    osc.start(now + offset);
    osc.stop(now + offset + 0.18);
  });
  if (navigator.vibrate) navigator.vibrate([120, 60, 120]);
}

function fmtClock(sec) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

function stepTimer(text) {
  const min = String(text).match(/(\d+)(?:\s*[–—-]\s*(\d+))?\s*(?:min|minute)/i);
  if (min) {
    const n = parseInt(min[2] || min[1], 10);
    if (n > 0 && n <= 240) return { sec: n * 60, label: `Start ${n} min timer` };
  }
  const sec = String(text).match(/(\d+)\s*(?:sec|second)/i);
  if (sec) {
    const n = parseInt(sec[1], 10);
    if (n > 0 && n <= 600) return { sec: n, label: `Start ${n} sec timer` };
  }
  return null;
}

function startTimer(sec, btn) {
  if (!sec || !btn) return;
  if (activeTimer && activeTimer.btn === btn) { stopTimer(); return; }
  stopTimer();
  initAudio();
  const span = btn.querySelector('span');
  const original = btn.dataset.label || (span ? span.textContent : 'Start timer');
  const end = Date.now() + sec * 1000;
  btn.dataset.label = original;
  btn.classList.add('running');
  btn.classList.remove('done');
  btn.disabled = false;

  activeTimer = { btn, original, id: null };
  const tick = () => {
    if (!activeTimer || activeTimer.btn !== btn) return;
    const left = Math.max(0, Math.ceil((end - Date.now()) / 1000));
    if (span) span.textContent = fmtClock(left);
    btn.setAttribute('aria-label', `Timer running, ${fmtClock(left)} left. Tap to stop.`);
    if (left <= 0) finishTimer();
  };
  activeTimer.id = setInterval(tick, 250);
  tick();
}

function finishTimer() {
  if (!activeTimer) return;
  clearInterval(activeTimer.id);
  const { btn, original } = activeTimer;
  activeTimer = null;
  btn.classList.remove('running');
  btn.classList.add('done');
  const span = btn.querySelector('span');
  if (span) span.textContent = 'Done — timer!';
  btn.disabled = true;
  beep();
  setTimeout(() => {
    if (!activeTimer && span && btn.classList.contains('done')) {
      btn.classList.remove('done');
      btn.disabled = false;
      span.textContent = original;
    }
  }, 9000);
}

function stopTimer() {
  if (!activeTimer) return;
  clearInterval(activeTimer.id);
  const { btn, original } = activeTimer;
  activeTimer = null;
  btn.classList.remove('running');
  btn.disabled = false;
  const span = btn.querySelector('span');
  if (span) span.textContent = original;
}

/* ============================================================
   wake lock
   ============================================================ */
async function requestWakeLock() {
  try {
    if ('wakeLock' in navigator) {
      wakeLock = await navigator.wakeLock.request('screen');
      wakeLock.addEventListener('release', () => { wakeLock = null; });
    }
  } catch (e) { wakeLock = null; }
}

function releaseWakeLock() {
  try { if (wakeLock) wakeLock.release(); } catch (e) { /* noop */ }
  wakeLock = null;
}

/* ============================================================
   actions
   ============================================================ */
function scrollResults() {
  const el = $('.results');
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function loadDemo() {
  state.ing = [];
  state.minutes = 40;
  state.tab = 'now';
  state.diet = 'all';
  addIngredientText('3 eggs, half an onion, canned tomatoes, garlic, pasta, bread, butter, cheese');
  scrollResults();
}

function handleEmptyAction(e) {
  const btn = e.target.closest('[data-act]');
  if (!btn) return;
  const act = btn.dataset.act;
  if (act === 'demo') loadDemo();
  else if (act === 'tab-all') { state.tab = 'all'; render(); }
  else if (act === 'tab-almost') { state.tab = 'almost'; render(); }
  else if (act === 'tab-now') { state.tab = 'now'; render(); }
  else if (act === 'more-time') { state.minutes = 999; render(); }
  else if (act === 'clear-diet') { state.diet = 'all'; render(); }
  else if (act === 'settings') openSide('settings');
}

/* ============================================================
   wiring
   ============================================================ */
function bind() {
  $('#addForm').addEventListener('submit', e => {
    e.preventDefault();
    const input = $('#ingInput');
    const value = input.value.trim();
    if (!value) { input.focus(); return; }
    addIngredientText(value);
    input.value = '';
    input.focus();
  });

  $('#chips').addEventListener('click', e => {
    const remove = e.target.closest('[data-remove]');
    if (remove) { removeIngredient(remove.dataset.remove); return; }
    if (e.target.closest('#clearChips')) {
      state.ing = [];
      render();
      toast('Basket cleared');
    }
  });

  $('#quickAdd').addEventListener('click', e => {
    const btn = e.target.closest('[data-quick]');
    if (!btn) return;
    addParsed({ k: btn.dataset.quick, name: btn.dataset.label, q: null, u: '' });
    toast(`Added ${btn.dataset.label}`);
    render();
  });

  $('#timeChips').addEventListener('click', e => {
    const btn = e.target.closest('[data-min]');
    if (!btn) return;
    state.minutes = Number(btn.dataset.min);
    render();
  });

  $('#tabs').addEventListener('click', e => {
    const btn = e.target.closest('[data-tab]');
    if (!btn) return;
    state.tab = btn.dataset.tab;
    render();
  });

  $('#dietRow').addEventListener('click', e => {
    const btn = e.target.closest('[data-diet]');
    if (!btn) return;
    state.diet = btn.dataset.diet;
    render();
  });

  $('#staplesLine').addEventListener('click', () => openSide('settings'));
  $('#brandBtn').addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  $('#btnSaved').addEventListener('click', () => openSide('saved'));
  $('#btnList').addEventListener('click', () => openSide('list'));
  $('#btnSettings').addEventListener('click', () => openSide('settings'));

  $('#cards').addEventListener('click', e => {
    const heart = e.target.closest('[data-heart]');
    if (heart) {
      e.preventDefault();
      e.stopPropagation();
      toggleSaved(heart.dataset.heart);
      return;
    }
    const card = e.target.closest('[data-open]');
    if (card) openRecipe(card.dataset.open);
  });

  $('#empty').addEventListener('click', handleEmptyAction);

  $('#sheetClose').addEventListener('click', closeRecipe);
  $('#sheetHeart').addEventListener('click', () => {
    if (currentRecipe) toggleSaved(currentRecipe.id);
  });
  $('#sheetBody').addEventListener('click', onSheetClick);

  $('#scrim').addEventListener('click', closeRecipe);
  $('#sideScrim').addEventListener('click', closeSide);
  $('#sideClose').addEventListener('click', closeSide);
  $('#sideBody').addEventListener('click', onSideClick);

  $('#cookClose').addEventListener('click', closeCook);
  $('#cookNext').addEventListener('click', cookNext);
  $('#cookPrev').addEventListener('click', () => {
    if (cookIdx > 0) { cookIdx--; renderCook(); }
  });
  $('#cookTimer').addEventListener('click', e => {
    const btn = e.currentTarget;
    if (btn.disabled) return;
    const sec = Number(btn.dataset.sec);
    if (sec) startTimer(sec, btn);
  });
  $('#cookIngBtn').addEventListener('click', () => {
    const panel = $('#cookIngredients');
    panel.hidden = !panel.hidden;
    $('#cookIngBtn').setAttribute('aria-pressed', String(!panel.hidden));
  });

  document.addEventListener('submit', e => {
    if (e.target.id !== 'manualItemForm') return;
    e.preventDefault();
    const input = $('#manualItem');
    if (!input) return;
    const value = input.value.trim();
    if (!value) return;
    if (state.list.some(x => x.name.toLowerCase() === value.toLowerCase())) {
      toast('Already on your list');
      input.value = '';
      input.focus();
      return;
    }
    state.list.push({
      id: `li_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      name: value,
      source: '',
      checked: false
    });
    save();
    renderBadges();
    renderSide(true);
    toast('Added to list');
    setTimeout(() => { const fresh = $('#manualItem'); if (fresh) fresh.focus(); }, 0);
  });

  document.addEventListener('keydown', e => {
    const typing = ['INPUT', 'TEXTAREA'].includes(document.activeElement && document.activeElement.tagName);
    if (e.key === 'Escape') {
      if ($('#cookOverlay').classList.contains('is-open')) closeCook();
      else if ($('#sideSheet').classList.contains('is-open')) closeSide();
      else if ($('#recipeSheet').classList.contains('is-open')) closeRecipe();
      return;
    }
    if ($('#cookOverlay').classList.contains('is-open') && !typing) {
      if (e.key === 'ArrowRight') { e.preventDefault(); cookNext(); }
      if (e.key === 'ArrowLeft') { e.preventDefault(); if (cookIdx > 0) { cookIdx--; renderCook(); } }
    }
  });

  document.addEventListener('rsw:saved', () => {
    if (!currentRecipe) return;
    const on = state.saved.includes(currentRecipe.id);
    const heart = $('#sheetHeart');
    heart.classList.toggle('is-on', on);
    heart.setAttribute('aria-pressed', on);
    heart.setAttribute('aria-label', `${on ? 'Remove from saved' : 'Save'} ${currentRecipe.title}`);
  });

  // Re-acquire the screen wake lock after a tab switch while cooking.
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && $('#cookOverlay').classList.contains('is-open') && !wakeLock) {
      requestWakeLock();
    }
  });

  $('#ingInput').addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      e.preventDefault();
      $('#addForm').requestSubmit();
    }
  });
}

function init() {
  bind();
  render();
  if ('serviceWorker' in navigator && (location.protocol === 'http:' || location.protocol === 'https:')) {
    navigator.serviceWorker.register('./sw.js').catch(() => { /* offline mode unavailable */ });
  }
}

document.addEventListener('DOMContentLoaded', init);
