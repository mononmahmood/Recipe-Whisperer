'use strict';

/* ============================================================
   helpers
   ============================================================ */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

const esc = (s) => String(s).replace(/[&<>"']/g, c => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
}[c]));

const clamp = (n, min, max) => Math.min(max, Math.max(min, n));
const cap = (s) => s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
const plural = (n, one, many) => n === 1 ? one : many;

const LS_KEY = 'rsw.v1';
const RECIPE_BY_ID = Object.fromEntries(RECIPES.map(r => [r.id, r]));
const ALL_KEYS = new Set(RECIPES.flatMap(r => r.ing.map(i => i.k)));
const STAPLE_LABEL = Object.fromEntries(STAPLE_CHOICES);
const TIME_OPTIONS = [15, 30, 40, 60, 999];
const DIETS = [
  ['all', 'All recipes'],
  ['vegetarian', 'Vegetarian'],
  ['vegan', 'Vegan'],
  ['high-protein', 'High protein'],
  ['one-pan', 'One pan']
];
const QUICK_ADD = [
  ['egg', 'eggs'], ['rice', 'rice'], ['pasta', 'pasta'], ['chicken', 'chicken'],
  ['onion', 'onion'], ['garlic', 'garlic'], ['tomato-canned', 'canned tomatoes'],
  ['cheese', 'cheese'], ['bread', 'bread'], ['potato', 'potatoes'],
  ['spinach', 'spinach'], ['butter', 'butter'], ['milk', 'milk'],
  ['chickpea', 'chickpeas'], ['lemon', 'lemon'], ['tortilla', 'tortillas'],
  ['beans', 'beans'], ['mushroom', 'mushrooms'], ['carrot', 'carrots'],
  ['yogurt', 'yogurt'], ['flour', 'flour']
];

const wordsToNum = {
  half: 0.5, quarter: 0.25, third: 1 / 3, one: 1, two: 2, three: 3,
  four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10,
  dozen: 12, couple: 2, few: 3
};

const UNITS = {
  kg: 'kg', kilo: 'kg', kilos: 'kg', kilogram: 'kg', kilograms: 'kg',
  g: 'g', gram: 'g', grams: 'g',
  ml: 'ml', millilitre: 'ml', millilitres: 'ml', milliliter: 'ml', milliliters: 'ml',
  l: 'l', litre: 'l', litres: 'l', liter: 'l', liters: 'l',
  tsp: 'tsp', teaspoon: 'tsp', teaspoons: 'tsp', tsps: 'tsp',
  tbsp: 'tbsp', tablespoon: 'tbsp', tablespoons: 'tbsp', tbsps: 'tbsp', tbs: 'tbsp',
  cup: 'cup', cups: 'cup',
  clove: 'clove', cloves: 'clove',
  can: 'can', cans: 'can', tin: 'can', tins: 'can',
  slice: 'slice', slices: 'slice',
  sprig: 'sprig', sprigs: 'sprig',
  bunch: 'bunch', bunches: 'bunch',
  handful: 'handful', handfuls: 'handful',
  pinch: 'pinch', pinches: 'pinch',
  sheet: 'sheet', sheets: 'sheet',
  fillet: 'fillet', fillets: 'fillet', filet: 'fillet', filets: 'fillet',
  piece: 'piece', pieces: 'piece',
  head: 'head', heads: 'head',
  pack: 'pack', packs: 'pack', packet: 'pack', packets: 'pack'
};

const UNIT_PLURAL = {
  cup: 'cups', clove: 'cloves', can: 'cans', slice: 'slices', sprig: 'sprigs',
  bunch: 'bunches', handful: 'handfuls', pinch: 'pinches', sheet: 'sheets',
  fillet: 'fillets', piece: 'pieces', head: 'heads', pack: 'packs'
};

/* ============================================================
   state
   ============================================================ */
function defaultState() {
  return {
    ing: [],
    minutes: 40,
    staples: DEFAULT_STAPLES.slice(),
    target: 2,
    saved: [],
    list: [],
    tab: 'now',
    diet: 'all'
  };
}

function loadState() {
  const base = defaultState();
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return base;
    const saved = JSON.parse(raw);
    const merged = { ...base, ...saved };
    merged.ing = Array.isArray(merged.ing) ? merged.ing.filter(i => i && i.k).map(i => ({
      k: String(i.k), name: String(i.name || i.k),
      q: typeof i.q === 'number' ? i.q : null,
      u: typeof i.u === 'string' ? i.u : ''
    })) : [];
    merged.staples = Array.isArray(merged.staples) ? merged.staples : base.staples;
    merged.saved = Array.isArray(merged.saved) ? merged.saved.filter(id => RECIPE_BY_ID[id]) : [];
    merged.list = Array.isArray(merged.list) ? merged.list.filter(x => x && x.name) : [];
    merged.minutes = TIME_OPTIONS.includes(merged.minutes) ? merged.minutes : 40;
    merged.target = clamp(parseInt(merged.target, 10) || 2, 1, 12);
    merged.tab = ['now', 'almost', 'all'].includes(merged.tab) ? merged.tab : 'now';
    merged.diet = DIETS.some(d => d[0] === merged.diet) ? merged.diet : 'all';
    return merged;
  } catch (e) {
    return base;
  }
}

let state = loadState();
let currentRecipe = null;
let detailServings = 2;
let checkedIngs = new Set();
let activeTimer = null;
let lastFocus = null;
let toastTimer = null;

function save() {
  try { localStorage.setItem(LS_KEY, JSON.stringify(state)); } catch (e) { /* private mode */ }
}

function toast(msg) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('is-on');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('is-on'), 2400);
}

/* ============================================================
   ingredient parsing
   ============================================================ */
function singularWord(w) {
  if (/(ies)$/.test(w)) return w.replace(/ies$/, 'y');
  if (/(oes)$/.test(w)) return w.replace(/oes$/, 'o');
  if (/(ses|xes|zes|ches|shes)$/.test(w)) return w.replace(/es$/, '');
  if (/(us|is|ous)$/.test(w)) return w;
  if (/s$/.test(w) && !/ss$/.test(w)) return w.replace(/s$/, '');
  return w;
}

function singularName(name) {
  return name.replace(/([a-z]+)$/i, w => singularWord(w));
}

function cleanName(raw) {
  let n = raw
    .toLowerCase()
    .replace(/\([^)]*\)/g, ' ')
    .replace(/[.!?]+$/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  n = n.replace(/^(of|the|my|some)\s+/i, '');
  n = n.replace(/^(a|an)\s+/i, '');
  n = n.replace(/^(bit|little)\s+of\s+/i, '');
  n = n.replace(/^of\s+/i, '');
  return n.trim();
}

function canonical(name) {
  const n = cleanName(name);
  if (!n) return '';
  const noDesc = n
    .replace(/\b(fresh|large|small|medium|ripe|frozen|canned|tinned|cooked|raw|baby|boneless|skinless|organic|free range|extra virgin|ground|minced|chopped|diced|sliced|grated|whole|plain|all purpose)\b/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  const candidates = [n, noDesc, singularName(n), singularName(noDesc)];
  const words = n.split(' ');
  if (words.length > 1) {
    candidates.push(words.slice(-2).join(' '));
    candidates.push(words[words.length - 1]);
    candidates.push(singularName(words[words.length - 1]));
  }
  for (const c of candidates) {
    if (ALIASES[c]) return ALIASES[c];
    if (ALL_KEYS.has(c)) return c;
  }
  return noDesc || n;
}

function parseIngredientLine(raw) {
  let s = String(raw || '').toLowerCase().replace(/\u00a0/g, ' ').trim();
  if (!s) return null;
  s = s.replace(/^[-•*]\s*/, '');
  s = s
    .replace(/½/g, '1/2').replace(/¼/g, '1/4').replace(/¾/g, '3/4')
    .replace(/⅓/g, '1/3').replace(/⅔/g, '2/3').replace(/⅛/g, '1/8')
    .replace(/⅜/g, '3/8').replace(/⅝/g, '5/8').replace(/⅞/g, '7/8');

  let q = null;
  let unit = '';
  const numMatch = s.match(/^(\d+\s+\d+\s*\/\s*\d+|\d+\s*\/\s*\d+|\d+(?:[.,]\d+)?)/);
  if (numMatch) {
    const rawNum = numMatch[0].trim();
    if (rawNum.includes(' ')) {
      const bits = rawNum.split(/\s+/);
      const frac = bits[1].split('/');
      q = parseInt(bits[0], 10) + (parseInt(frac[0], 10) / parseInt(frac[1], 10));
    } else if (rawNum.includes('/')) {
      const frac = rawNum.split('/');
      q = parseInt(frac[0], 10) / parseInt(frac[1], 10);
    } else {
      q = parseFloat(rawNum.replace(',', '.'));
    }
    s = s.slice(numMatch[0].length).trim();
  } else {
    const wm = s.match(/^(half|quarter|third|one|two|three|four|five|six|seven|eight|nine|ten|dozen|couple|few)\b\s*(.*)$/);
    if (wm) {
      q = wordsToNum[wm[1]];
      s = wm[2].trim();
    } else {
      const am = s.match(/^(a|an)\b\s+(.*)$/);
      if (am && !/^(little|bit|few|lot|pinch|handful)\b/.test(am[2])) {
        q = 1;
        s = am[2].trim();
      }
    }
  }

  // unit immediately after the number, with or without a space
  const um = s.match(/^([a-z]+)\.?\b\s*(.*)$/);
  if (um && UNITS[um[1]]) {
    unit = UNITS[um[1]];
    if (q == null) q = 1;
    s = um[2].trim();
  } else if (/^(handful|pinch|bunch)\b/i.test(s)) {
    const hm = s.match(/^(handful|pinch|bunch)\b\s*(?:of\s+)?(.*)$/i);
    unit = UNITS[hm[1].toLowerCase()];
    if (q == null) q = 1;
    s = hm[2].trim();
  }

  const name = cleanName(s);
  if (!name) return null;
  const k = canonical(name);
  if (!k) return null;
  return { k, name, q: (q != null && q > 0 ? q : null), u: unit, raw: String(raw).trim() };
}

function addParsed(p) {
  if (!p) return 'skip';
  const existing = state.ing.find(i => i.k === p.k);
  if (existing) {
    if (p.q != null) {
      existing.q = p.q;
      existing.u = p.u;
      existing.name = p.name;
      return 'updated';
    }
    return 'duplicate';
  }
  state.ing.push(p);
  return 'added';
}

function addIngredientText(text) {
  const pieces = String(text).split(/[,;\n]+/).map(x => x.trim()).filter(Boolean);
  if (!pieces.length) return;
  let added = 0, updated = 0, duplicate = 0;
  let last = null;
  for (const piece of pieces) {
    const p = parseIngredientLine(piece);
    if (!p) continue;
    last = p;
    const res = addParsed(p);
    if (res === 'added') added++;
    else if (res === 'updated') updated++;
    else if (res === 'duplicate') duplicate++;
  }
  if (added + updated === 0 && duplicate > 0 && last) {
    toast(`Already have ${last.name}`);
  } else if (added + updated === 1 && last) {
    toast(`${updated ? 'Updated' : 'Added'} ${last.name}`);
  } else if (added + updated > 1) {
    toast(`Added ${added + updated} ingredients`);
  }
  if (added + updated > 0) {
    state.tab = 'now';
    if (state.diet !== 'all') { /* keep their filter */ }
  }
  render();
}

function removeIngredient(k) {
  state.ing = state.ing.filter(i => i.k !== k);
  render();
}

/* ============================================================
   amount formatting
   ============================================================ */
const DIMENSION = (u = '') => {
  if (u === 'g' || u === 'kg') return 'mass';
  if (['ml', 'l', 'tsp', 'tbsp', 'cup'].includes(u)) return 'vol';
  if (!u || ['clove', 'can', 'slice', 'sprig', 'bunch', 'handful', 'pinch', 'sheet', 'fillet', 'piece', 'head', 'pack'].includes(u)) return 'count';
  return null;
};

const TO_BASE = (q, u = '') => {
  if (u === 'kg' || u === 'l') return q * 1000;
  if (u === 'tsp') return q * 5;
  if (u === 'tbsp') return q * 15;
  if (u === 'cup') return q * 240;
  return q;
};

function trimNum(n, digits = 2) {
  return parseFloat(n.toFixed(digits)).toString();
}

function fmtQty(n) {
  if (n == null || !isFinite(n) || n <= 0) return '';
  if (n < 0.06) return '';
  if (n >= 10 && Math.abs(n - Math.round(n)) < 0.01) return String(Math.round(n));
  const whole = Math.floor(n + 1e-6);
  const frac = n - whole;
  const fractions = [[0, ''], [1 / 8, '⅛'], [1 / 4, '¼'], [1 / 3, '⅓'], [1 / 2, '½'], [2 / 3, '⅔'], [3 / 4, '¾'], [1, '']];
  let best = fractions[0];
  let bestDiff = 9;
  for (const f of fractions) {
    const d = Math.abs(frac - f[0]);
    if (d < bestDiff) { bestDiff = d; best = f; }
  }
  if (bestDiff > 0.07) return trimNum(Math.round(n * 10) / 10, 1);
  if (best[0] === 1) return String(whole + 1);
  if (whole === 0) return best[1] || '0';
  return whole + best[1];
}

function unitText(u, q) {
  if (!u) return '';
  if (UNIT_PLURAL[u]) return q > 1.0001 ? UNIT_PLURAL[u] : u;
  return u;
}

function amountText(q, u = '') {
  if (q == null || !isFinite(q) || q <= 0) return '';
  u = u || '';
  if (u === 'g' || u === 'kg') {
    const grams = u === 'kg' ? q * 1000 : q;
    if (grams >= 1000) return `${trimNum(grams / 1000, 2)} kg`;
    if (grams >= 20) return `${Math.round(grams / 5) * 5} g`;
    return `${trimNum(grams, 1)} g`;
  }
  if (u === 'ml' || u === 'l') {
    const ml = u === 'l' ? q * 1000 : q;
    if (ml >= 1000) return `${trimNum(ml / 1000, 2)} L`;
    return `${Math.round(ml)} ml`;
  }
  const amount = fmtQty(q);
  if (!amount) return '';
  return u ? `${amount} ${unitText(u, q)}` : amount;
}

function itemLabel(ing, qty) {
  let name = ing.n || ing.name || ing.k;
  if (qty != null && qty <= 1.0001 && !ing.u) name = singularName(name);
  return name;
}

function fullIngredient(ing, qty) {
  const amt = amountText(qty, ing.u);
  const name = itemLabel(ing, qty);
  return amt ? `${amt} ${name}` : name;
}

/* ============================================================
   matching
   ============================================================ */
function userMap() {
  const map = new Map();
  for (const i of state.ing) if (!map.has(i.k)) map.set(i.k, i);
  return map;
}

function compareQty(haveQ, haveU, needQ, needU) {
  const dh = DIMENSION(haveU);
  const dn = DIMENSION(needU);
  if (!dh || !dn || dh !== dn) return null;
  if (['pinch', 'handful'].includes(haveU) || ['pinch', 'handful'].includes(needU)) return null;
  return TO_BASE(haveQ, haveU) - TO_BASE(needQ, needU);
}

function analyze(recipe, servings) {
  const has = userMap();
  const staples = new Set(state.staples);
  const target = (typeof servings === 'number') ? servings : state.target;
  const factor = target / recipe.serves;
  const missing = [];
  const short = [];
  const used = [];

  for (const ing of recipe.ing) {
    if (ing.opt) continue;
    const mine = has.get(ing.k);
    if (staples.has(ing.k)) {
      if (mine) used.push(ing);
      continue;
    }
    if (!mine) { missing.push(ing); continue; }
    used.push(ing);
    if (mine.q != null && ing.q != null) {
      const need = ing.q * factor;
      const diff = compareQty(mine.q, mine.u, need, ing.u);
      if (diff != null && diff < -0.0001) {
        short.push({ ing, have: mine.q, haveU: mine.u, need });
      }
    }
  }
  return { missing, short, used, canNow: missing.length === 0 && short.length === 0, factor };
}

function passesTime(recipe) {
  return state.minutes === 999 || recipe.time <= state.minutes;
}

function passesDiet(recipe) {
  return state.diet === 'all' || recipe.tags.includes(state.diet);
}

function scoreAndSort(list) {
  return list.sort((a, b) => {
    if (a.missing.length !== b.missing.length) return a.missing.length - b.missing.length;
    if (a.short.length !== b.short.length) return a.short.length - b.short.length;
    if (b.used.length !== a.used.length) return b.used.length - a.used.length;
    return a.recipe.time - b.recipe.time;
  });
}

function currentResults() {
  const pool = RECIPES.filter(r => passesTime(r) && passesDiet(r)).map(recipe => {
    const a = analyze(recipe);
    return { recipe, ...a };
  });
  const now = scoreAndSort(pool.filter(x => x.canNow));
  const almost = scoreAndSort(pool.filter(x => !x.canNow && x.missing.length <= 2));
  return { pool, now, almost };
}

/* ============================================================
   rendering: main screen
   ============================================================ */
function render() {
  renderChips();
  renderQuickAdd();
  renderTime();
  renderStaplesLine();
  renderDiet();
  renderResults();
  renderBadges();
  save();
}

function renderChips() {
  const wrap = $('#chips');
  if (!state.ing.length) { wrap.innerHTML = ''; return; }
  wrap.innerHTML = state.ing.map(i => {
    const amt = amountText(i.q, i.u);
    return `<span class="chip">
      ${amt ? `<span class="qty">${esc(amt)}</span>` : ''}
      <span>${esc(i.name)}</span>
      <button type="button" data-remove="${esc(i.k)}" aria-label="Remove ${esc(i.name)}">
        <svg class="icon"><use href="#i-x"/></svg>
      </button>
    </span>`;
  }).join('') + `<button type="button" class="chip-clear" id="clearChips">Clear all</button>`;
}

function renderQuickAdd() {
  const wrap = $('#quickAdd');
  const have = new Set(state.ing.map(i => i.k));
  const picks = QUICK_ADD.filter(([k]) => !have.has(k)).slice(0, 14);
  wrap.innerHTML = picks.map(([k, label]) =>
    `<button type="button" class="quick-chip" data-quick="${esc(k)}" data-label="${esc(label)}">+ ${esc(label)}</button>`
  ).join('');
}

function renderTime() {
  $('#timeChips').innerHTML = TIME_OPTIONS.map(m =>
    `<button type="button" class="${state.minutes === m ? 'is-on' : ''}" data-min="${m}" aria-pressed="${state.minutes === m}">
      ${m === 999 ? 'Any' : `${m} min`}
    </button>`
  ).join('');
}

function renderStaplesLine() {
  const labels = state.staples.slice(0, 3).map(k => STAPLE_LABEL[k] || k);
  const extra = state.staples.length - labels.length;
  const text = labels.length
    ? `Assuming you have ${labels.join(', ').toLowerCase()}${extra > 0 ? ` +${extra} more` : ''}`
    : 'No pantry staples assumed — tap to add';
  $('#staplesText').textContent = text;
}

function renderDiet() {
  $('#dietRow').innerHTML = DIETS.map(([key, label]) =>
    `<button type="button" class="pill ${state.diet === key ? 'is-on' : ''}" data-diet="${key}" aria-pressed="${state.diet === key}">${label}</button>`
  ).join('');
}

function renderBadges() {
  const saved = $('#savedBadge');
  saved.hidden = state.saved.length === 0;
  saved.textContent = state.saved.length;
  const openList = state.list.filter(x => !x.checked).length;
  const list = $('#listBadge');
  list.hidden = openList === 0;
  list.textContent = openList;
}

function renderResults() {
  const { pool, now, almost } = currentResults();
  const nNow = now.length, nAlmost = almost.length, nAll = pool.length;

  $('#nNow').textContent = nNow;
  $('#nAlmost').textContent = nAlmost;
  $('#nAll').textContent = nAll;
  $$('#tabs .tab').forEach(t => {
    const on = t.dataset.tab === state.tab;
    t.classList.toggle('is-on', on);
    t.setAttribute('aria-selected', on);
  });

  const hasIng = state.ing.length > 0;
  const mins = state.minutes === 999 ? 'all the time in the world' : `${state.minutes} minutes`;
  let title, meta;

  if (!hasIng) {
    title = "Tell me what's in the kitchen.";
    meta = "I'll only show recipes you can actually cook. No account, no ads, no 40-minute scroll.";
  } else {
    const names = state.ing.slice(0, 2).map(i => fullIngredient(i, i.q).toLowerCase()).join(' and ');
    if (nNow > 0) {
      title = `${cap(names)} — ${mins}. ${nNow} ${plural(nNow, 'dinner', 'dinners')} you can cook right now.`;
    } else if (nAlmost > 0) {
      title = `${cap(names)} — ${mins}. Nothing perfect yet: ${nAlmost} ${plural(nAlmost, 'recipe is', 'recipes are')} one or two ingredients away.`;
    } else {
      title = `${cap(names)} — ${mins}. I need a little more to work with.`;
    }
    meta = `${nAll} ${plural(nAll, 'recipe', 'recipes')} ${state.diet === 'all' ? 'checked' : `match “${DIETS.find(d => d[0] === state.diet)[1]}”`} · ${state.staples.length} pantry staples assumed`;
  }
  $('#whisperTitle').textContent = title;
  $('#whisperMeta').textContent = meta;

  let list;
  if (state.tab === 'now') list = now;
  else if (state.tab === 'almost') list = almost;
  else list = scoreAndSort(pool.slice());

  const cards = $('#cards');
  const empty = $('#empty');
  cards.innerHTML = list.map((item, i) => cardHTML(item, i)).join('');

  if (!list.length) {
    cards.innerHTML = '';
    empty.hidden = false;
    empty.innerHTML = emptyHTML();
  } else {
    empty.hidden = true;
    empty.innerHTML = '';
  }

  if (state.tab === 'now' && !hasIng) {
    cards.innerHTML = '';
    empty.hidden = false;
    empty.innerHTML = introHTML();
  }
}

function cardHTML(item, index) {
  const r = item.recipe;
  const cat = CAT_META[r.cat] || CAT_META.veg;
  const saved = state.saved.includes(r.id);
  const perish = item.used.find(i => PERISHABLE.includes(i.k));
  const miss = item.missing.slice(0, 2);
  const missExtra = item.missing.length - miss.length;

  const footLeft = item.canNow
    ? `<span class="ready-badge"><svg class="icon"><use href="#i-check"/></svg> Everything's here</span>`
    : `<span class="miss-row"><span style="font-size:11px;color:var(--muted)">Needs</span>${miss.map(m => `<span class="miss-chip">${esc(m.n || m.k)}</span>`).join('')}${missExtra > 0 ? `<span class="miss-chip">+${missExtra}</span>` : ''}${item.short.length && !item.missing.length ? `<span class="miss-chip">a little more ${esc(item.short[0].ing.n || item.short[0].ing.k)}</span>` : ''}</span>`;

  return `<article class="card" data-open="${esc(r.id)}" style="--i:${index};--cat:${cat.hue}">
    <div class="card-head">
      <span class="cat-tag">${esc(cat.label)}</span>
      <div class="card-tools">
        <span class="time-tag"><svg class="icon"><use href="#i-clock"/></svg>${r.time} min</span>
        <button type="button" class="heart-btn ${saved ? 'is-on' : ''}" data-heart="${esc(r.id)}" aria-label="${saved ? 'Remove from saved' : 'Save'} ${esc(r.title)}" aria-pressed="${saved}">
          <svg class="icon"><use href="#i-heart"/></svg>
        </button>
      </div>
    </div>
    <h3>${esc(r.title)}</h3>
    <p class="card-blurb">${esc(r.blurb)}</p>
    ${perish ? `<span class="useup"><svg class="icon"><use href="#i-leaf"/></svg> Use it up: ${esc(SHORT_LABEL[perish.k] || perish.k)}</span>` : ''}
    <div class="card-foot">
      ${footLeft}
      <span class="serves">Serves ${r.serves}</span>
    </div>
  </article>`;
}

function emptyHTML() {
  const { pool, almost } = currentResults();
  if (state.diet !== 'all' && !pool.length) {
    return `<div class="icon-big"><svg class="icon"><use href="#i-leaf"/></svg></div>
      <h3>No ${esc(DIETS.find(d => d[0] === state.diet)[1].toLowerCase())} matches</h3>
      <p>Try a different filter, or add a few more ingredients.</p>
      <div class="empty-actions"><button class="btn primary" data-act="clear-diet">Show all recipes</button></div>`;
  }
  if (state.minutes !== 999 && !pool.length) {
    return `<div class="icon-big"><svg class="icon"><use href="#i-clock"/></svg></div>
      <h3>Nothing fits in ${state.minutes} minutes</h3>
      <p>Every good dinner here needs a little longer. Let's open up the clock.</p>
      <div class="empty-actions"><button class="btn primary" data-act="more-time">I've got more time</button></div>`;
  }
  if (state.tab === 'now' && almost.length) {
    return `<div class="icon-big"><svg class="icon"><use href="#i-spark"/></svg></div>
      <h3>So close.</h3>
      <p>${almost.length} ${plural(almost.length, 'recipe is', 'recipes are')} one or two ingredients away. Add them, or see what you're missing.</p>
      <div class="empty-actions"><button class="btn primary" data-act="tab-almost">Show almost-there recipes</button><button class="btn ghost-btn" data-act="tab-all">Browse everything</button></div>`;
  }
  if (state.tab === 'almost') {
    return `<div class="icon-big"><svg class="icon"><use href="#i-check"/></svg></div>
      <h3>Nothing is that close</h3>
      <p>Add a couple more things from your kitchen, or browse every recipe for inspiration.</p>
      <div class="empty-actions"><button class="btn primary" data-act="tab-all">Browse everything</button></div>`;
  }
  return `<div class="icon-big"><svg class="icon"><use href="#i-basket"/></svg></div>
    <h3>Nothing matches yet</h3>
    <p>Add two or three more ingredients — pantry basics count, and you can edit those in the staples settings.</p>
    <div class="empty-actions"><button class="btn primary" data-act="tab-now">Back to make-now</button><button class="btn ghost-btn" data-act="settings">Edit pantry staples</button></div>`;
}

function introHTML() {
  return `<div class="icon-big"><svg class="icon"><use href="#i-spark"/></svg></div>
    <h3>Dinner in three steps</h3>
    <p>1. Type what's in your fridge. 2. Pick how long you've got. 3. Cook the top match — every quantity scales to your table.</p>
    <div class="empty-actions">
      <button class="btn primary" data-act="demo">Try it: 3 eggs &amp; 40 minutes</button>
      <button class="btn ghost-btn" data-act="tab-all">Browse all recipes</button>
    </div>`;
}

function toggleSaved(id) {
  if (!RECIPE_BY_ID[id]) return;
  if (state.saved.includes(id)) {
    state.saved = state.saved.filter(x => x !== id);
    toast('Removed from saved');
  } else {
    state.saved.push(id);
    toast('Saved for later');
  }
  renderBadges();
  save();
  $$(`[data-heart="${id}"]`).forEach(btn => {
    const on = state.saved.includes(id);
    btn.classList.toggle('is-on', on);
    btn.setAttribute('aria-pressed', on);
    btn.setAttribute('aria-label', `${on ? 'Remove from saved' : 'Save'} ${RECIPE_BY_ID[id].title}`);
  });
  document.dispatchEvent(new CustomEvent('rsw:saved'));
}

function addToShoppingList(items, source) {
  let added = 0;
  for (const item of items) {
    const name = (item.n || item.k || '').toLowerCase().trim();
    if (!name) continue;
    if (state.list.some(x => x.name.toLowerCase() === name)) continue;
    state.list.push({
      id: `li_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      name,
      source: source || '',
      checked: false
    });
    added++;
  }
  renderBadges();
  save();
  if (added) toast(`Added ${added} ${plural(added, 'item', 'items')} to your list`);
  else toast('Already on your list');
  return added;
}
