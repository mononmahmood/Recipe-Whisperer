/* ---------------- BREAKFAST, SOUPS & SMALL PLATES ---------------- */
RECIPES.push(
{
  id: 'fluffy-pancakes',
  title: 'Fluffy Pancakes',
  blurb: 'Tall, soft pancakes from scratch. The weekend ritual worth learning.',
  cat: 'breakfast', serves: 4, time: 20,
  tags: ['vegetarian', 'brunch'],
  ing: [
    { k: 'flour', q: 1.5, u: 'cup' },
    { k: 'milk', q: 1.25, u: 'cup' },
    { k: 'egg', q: 2, u: '', n: 'eggs' },
    { k: 'baking powder', q: 2, u: 'tsp' },
    { k: 'sugar', q: 2, u: 'tbsp', pantry: true },
    { k: 'butter', q: 2, u: 'tbsp', n: 'butter, melted' },
    { k: 'salt', q: 0.5, u: 'tsp', pantry: true },
    { k: 'maple syrup', q: 4, u: 'tbsp', opt: true },
    { k: 'berries', q: 1, u: 'cup', opt: true }
  ],
  steps: [
    'Whisk the flour, baking powder, sugar and salt in a large bowl.',
    'In a jug, whisk the milk, eggs and melted butter. Pour into the dry ingredients and stir just until combined — lumps are fine.',
    'Rest the batter for 5 min while the pan heats over medium-low.',
    'Lightly butter the pan. Pour in small ladles of batter and cook for 2 min, until bubbles pop on the surface. Flip and cook 1 min more.',
    'Keep the cooked pancakes on a plate under a tea towel. Serve with syrup and berries.'
  ],
  tip: 'Do not overmix. A lumpy batter makes fluffy pancakes; a smooth one makes rubbery ones.'
},
{
  id: 'french-toast',
  title: 'Crispy French Toast',
  blurb: 'Golden outside, custardy inside. Use bread that is a day or two old.',
  cat: 'breakfast', serves: 2, time: 15,
  tags: ['vegetarian', 'quick', 'brunch'],
  ing: [
    { k: 'bread', q: 4, u: 'slice', n: 'thick slices of bread' },
    { k: 'egg', q: 2, u: '', n: 'eggs' },
    { k: 'milk', q: 0.5, u: 'cup' },
    { k: 'cinnamon', q: 1, u: 'tsp' },
    { k: 'butter', q: 1, u: 'tbsp' },
    { k: 'honey', q: 2, u: 'tbsp', opt: true },
    { k: 'berries', q: 0.5, u: 'cup', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Beat the eggs, milk, cinnamon and salt in a shallow dish.',
    'Soak each slice of bread for 20 sec a side. Do not let it fall apart.',
    'Melt half the butter in a non-stick pan over medium heat.',
    'Fry the slices for 2–3 min a side until deep golden. Add the rest of the butter for the second batch.',
    'Serve immediately with honey and berries.'
  ],
  tip: 'Medium heat, not high. High heat burns the outside before the custard sets in the middle.'
},
{
  id: 'overnight-oats',
  title: 'Overnight Oats',
  blurb: 'Five minutes at night, breakfast solved. No cooking, no excuses.',
  cat: 'breakfast', serves: 1, time: 5,
  tags: ['vegetarian', 'quick', 'brunch'],
  ing: [
    { k: 'oats', q: 0.5, u: 'cup' },
    { k: 'milk', q: 0.5, u: 'cup' },
    { k: 'yogurt', q: 0.33, u: 'cup' },
    { k: 'chia', q: 1, u: 'tbsp', opt: true },
    { k: 'honey', q: 1, u: 'tsp' },
    { k: 'berries', q: 0.5, u: 'cup', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Put the oats, milk, yogurt, chia and honey in a jar or bowl with a pinch of salt.',
    'Stir well, pressing the oats down so they are covered.',
    'Cover and refrigerate overnight, or for at least 4 hours.',
    'In the morning, loosen with a splash of milk and top with berries.'
  ],
  tip: 'Make three jars at once on Sunday. They keep for 4 days, so breakfast becomes a fridge door decision.'
},
{
  id: 'banana-smoothie',
  title: 'Banana Oat Smoothie',
  blurb: 'Thick, filling, and ready before your coffee brews. One blender cup.',
  cat: 'breakfast', serves: 1, time: 5,
  tags: ['vegetarian', 'quick', 'brunch'],
  ing: [
    { k: 'banana', q: 1, u: '', n: 'frozen banana' },
    { k: 'milk', q: 1, u: 'cup' },
    { k: 'oats', q: 2, u: 'tbsp' },
    { k: 'peanut butter', q: 1, u: 'tbsp', opt: true },
    { k: 'honey', q: 1, u: 'tsp', opt: true },
    { k: 'cinnamon', q: 1, u: 'pinch', opt: true }
  ],
  steps: [
    'Break the frozen banana into chunks.',
    'Blend everything on high for 45 sec until completely smooth.',
    'Add a splash more milk if it is too thick to drink through a straw.'
  ],
  tip: 'Freeze bananas when they go spotty. They make the smoothie cold and naturally sweet without ice.'
},
{
  id: 'tomato-soup-grilled-cheese',
  title: 'Tomato Soup & Grilled Cheese',
  blurb: 'The ultimate dunking combo. A blender soup that tastes like a long simmer.',
  cat: 'soup', serves: 4, time: 25,
  tags: ['vegetarian', 'comfort'],
  ing: [
    { k: 'tomato-canned', q: 800, u: 'g', n: 'canned tomatoes' },
    { k: 'onion', q: 1, u: '', n: 'onion' },
    { k: 'garlic', q: 3, u: 'clove' },
    { k: 'stock', q: 500, u: 'ml' },
    { k: 'bread', q: 8, u: 'slice' },
    { k: 'cheese', q: 150, u: 'g', n: 'cheese, sliced' },
    { k: 'butter', q: 2, u: 'tbsp' },
    { k: 'cream', q: 100, u: 'ml', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Cook the chopped onion in 1 tbsp butter for 5 min. Add the garlic for 30 sec.',
    'Add the tomatoes and stock. Simmer for 10 min, then blend until smooth (or leave it chunky).',
    'Stir in the cream if using, season, and keep warm.',
    'Butter one side of each slice of bread. Put cheese between two slices, buttered sides out.',
    'Toast in a dry pan over medium-low for 3 min a side, pressing lightly, until golden and molten. Cut and dunk.'
  ],
  tip: 'Low and slow for grilled cheese. High heat browns the bread before the cheese melts.'
},
{
  id: 'miso-soup',
  title: 'Miso Soup with Tofu',
  blurb: 'A ten-minute bowl of warmth. Gentle, savoury, and absurdly easy.',
  cat: 'soup', serves: 2, time: 10,
  tags: ['vegan', 'quick'],
  ing: [
    { k: 'miso', q: 2, u: 'tbsp' },
    { k: 'tofu', q: 200, u: 'g', n: 'silken or firm tofu' },
    { k: 'scallion', q: 2, u: '', n: 'spring onions' },
    { k: 'nori', q: 1, u: 'sheet', n: 'nori sheet', opt: true },
    { k: 'water', q: 700, u: 'ml', pantry: true },
    { k: 'soy sauce', q: 1, u: 'tsp', opt: true }
  ],
  steps: [
    'Heat the water to a gentle simmer — do not boil hard.',
    'Cube the tofu and add it for 2 min to warm through.',
    'Put the miso in a small bowl and whisk in a ladle of hot water until smooth. Stir it back into the pot.',
    'Taste and add a little soy sauce if it needs more depth.',
    'Serve with sliced spring onion and torn nori.'
  ],
  tip: 'Never boil miso — high heat kills the flavour and makes it grainy. Add it at the end, off the heat.'
},
{
  id: 'crispy-chickpea-pita',
  title: 'Crispy Chickpea Pita',
  blurb: 'Spiced chickpeas stuffed into warm pita with cool yogurt. Lunch in 20.',
  cat: 'veg', serves: 2, time: 20,
  tags: ['vegetarian', 'quick'],
  ing: [
    { k: 'chickpea', q: 400, u: 'g', n: 'canned chickpeas' },
    { k: 'pita', q: 2, u: '', n: 'pita breads' },
    { k: 'yogurt', q: 0.5, u: 'cup' },
    { k: 'cucumber', q: 0.5, u: '', n: 'cucumber' },
    { k: 'tomato', q: 1, u: '', n: 'tomato' },
    { k: 'cumin', q: 1, u: 'tsp' },
    { k: 'paprika', q: 0.5, u: 'tsp' },
    { k: 'lemon', q: 0.5, u: '' },
    { k: 'olive oil', q: 2, u: 'tbsp', pantry: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Drain and dry the chickpeas well. Toss with the olive oil, cumin, paprika and salt.',
    'Heat a wide pan over medium-high and fry the chickpeas for 6 min, shaking often, until crispy and blistered.',
    'Grate the cucumber and squeeze out the water. Mix with the yogurt, lemon juice and a pinch of salt.',
    'Warm the pita in the pan for 30 sec a side, then split open.',
    'Stuff with chickpeas, yogurt sauce, and diced tomato.'
  ],
  tip: 'Dry chickpeas crisp; wet ones pop and spit. Roll them in a tea towel before they hit the pan.'
},
{
  id: 'quesadilla',
  title: 'Crispy Bean Quesadilla',
  blurb: 'Golden, melty, and on the table in 15 minutes. A fridge-raid classic.',
  cat: 'veg', serves: 2, time: 15,
  tags: ['vegetarian', 'quick'],
  ing: [
    { k: 'tortilla', q: 4, u: '', n: 'large tortillas' },
    { k: 'cheese', q: 120, u: 'g', n: 'cheese, grated' },
    { k: 'beans', q: 200, u: 'g', n: 'black beans', opt: true },
    { k: 'salsa', q: 4, u: 'tbsp' },
    { k: 'avocado', q: 1, u: '', n: 'avocado', opt: true },
    { k: 'butter', q: 1, u: 'tbsp' },
    { k: 'salt', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Mash the beans with a pinch of salt if using.',
    'Lay a tortilla in a dry pan over medium heat. Scatter cheese over one half, add beans and a spoon of salsa, then more cheese.',
    'Fold the empty half over and press down with a spatula.',
    'Cook for 2 min until golden, then flip carefully and cook 2 min more. Add a little butter to the pan for the second side if you want extra crisp.',
    'Rest for 1 min, cut into wedges, and serve with avocado and extra salsa.'
  ],
  tip: 'Cheese on both sides of the filling is the structural secret — it glues the whole thing shut.'
}
);
