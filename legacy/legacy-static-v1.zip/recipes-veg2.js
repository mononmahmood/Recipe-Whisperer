/* ---------------- SMALL PLATES, SIDES & SOUPS ---------------- */
RECIPES.push(
{
  id: 'garlic-bread',
  title: 'Proper Garlic Bread',
  blurb: 'Crisp edges, soft middle, garlic butter in every crevice. Fifteen minutes.',
  cat: 'snack', serves: 4, time: 15,
  tags: ['vegetarian', 'quick'],
  ing: [
    { k: 'bread', q: 8, u: 'slice', n: 'slices of bread or half a baguette' },
    { k: 'butter', q: 4, u: 'tbsp', n: 'butter, softened' },
    { k: 'garlic', q: 4, u: 'clove' },
    { k: 'parsley', q: 1, u: 'handful', opt: true },
    { k: 'cheese', q: 50, u: 'g', n: 'parmesan or mozzarella', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Heat the oven to 220°C.',
    'Mash the softened butter with crushed garlic, chopped parsley and a pinch of salt.',
    'Slice the bread most of the way through, or cut into thick slices, and spread the butter generously into every cut.',
    'Wrap in foil and bake for 8 min, then open the foil and bake 4 min more for crisp edges.',
    'Add cheese for the last 3 min if you want it melty.'
  ],
  tip: 'Garlic butter freezes brilliantly. Make double, roll into a log, and cut off a coin whenever bread needs saving.'
},
{
  id: 'roast-broccoli',
  title: 'Roasted Broccoli with Lemon',
  blurb: 'The side that makes people fight over broccoli. Crispy, salty, lemony.',
  cat: 'snack', serves: 4, time: 20,
  tags: ['vegan', 'quick'],
  ing: [
    { k: 'broccoli', q: 2, u: '', n: 'heads of broccoli' },
    { k: 'olive oil', q: 3, u: 'tbsp', pantry: true },
    { k: 'garlic', q: 3, u: 'clove' },
    { k: 'lemon', q: 0.5, u: '' },
    { k: 'cheese', q: 30, u: 'g', n: 'parmesan', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Heat the oven to 220°C. Cut the broccoli into florets, keeping some stem — it is the sweetest part.',
    'Toss with olive oil, sliced garlic, salt and pepper on a large tray. Spread it out with space between pieces.',
    'Roast for 15 min, turning once, until the tips are dark and crispy.',
    'Squeeze over lemon and shower with parmesan.'
  ],
  tip: 'Dark brown broccoli tips are flavour, not a mistake. If you are nervous, check at 12 min and trust the crisp.'
},
{
  id: 'guacamole',
  title: 'Guacamole',
  blurb: 'Chunky, limey, and made in ten minutes. The correct amount is more.',
  cat: 'snack', serves: 4, time: 10,
  tags: ['vegan', 'quick'],
  ing: [
    { k: 'avocado', q: 3, u: '', n: 'ripe avocados' },
    { k: 'lime', q: 1, u: '' },
    { k: 'onion', q: 0.5, u: '', n: 'red onion' },
    { k: 'tomato', q: 1, u: '', n: 'tomato' },
    { k: 'cilantro', q: 0.5, u: 'cup', n: 'cilantro', opt: true },
    { k: 'chili flakes', q: 1, u: 'pinch', opt: true },
    { k: 'tortilla', q: 4, u: '', n: 'tortillas or chips, to serve', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Halve the avocados, scoop into a bowl, and mash with a fork — leave it chunky.',
    'Add the lime juice and a big pinch of salt. Taste; it should be bright, not flat.',
    'Finely chop the onion, tomato and cilantro and fold them in.',
    'Add chilli flakes and taste again. Serve right away.'
  ],
  tip: 'Salt and lime are the two dials. If it tastes boring, it almost always needs one or both — not more avocado.'
},
{
  id: 'yogurt-flatbread',
  title: 'Yogurt Flatbreads',
  blurb: 'Soft, puffy flatbreads with two ingredients you probably have. No yeast.',
  cat: 'snack', serves: 4, time: 25,
  tags: ['vegetarian'],
  ing: [
    { k: 'flour', q: 2, u: 'cup' },
    { k: 'yogurt', q: 1, u: 'cup' },
    { k: 'baking powder', q: 1, u: 'tsp' },
    { k: 'olive oil', q: 2, u: 'tbsp', pantry: true },
    { k: 'salt', q: 1, u: 'tsp', pantry: true }
  ],
  steps: [
    'Mix the flour, baking powder and salt. Add the yogurt and stir until a shaggy dough forms.',
    'Knead on a floured surface for 2 min until smooth. Cover and rest for 10 min.',
    'Divide into 6 balls and roll each into a thin circle, about 3 mm thick.',
    'Heat a dry pan over medium-high. Cook each flatbread for 1–2 min a side until puffed and spotted.',
    'Brush with olive oil and keep warm under a towel.'
  ],
  tip: 'The dough should be soft and slightly tacky. Add flour a spoon at a time only if it is too sticky to handle.'
},
{
  id: 'lentil-soup',
  title: 'Lemony Lentil Soup',
  blurb: 'Hearty, bright, and cheap. Freezes beautifully for emergency dinners.',
  cat: 'soup', serves: 4, time: 35,
  tags: ['vegan', 'one-pan', 'comfort'],
  ing: [
    { k: 'lentil', q: 1.5, u: 'cup', n: 'red or green lentils' },
    { k: 'carrot', q: 2, u: '' },
    { k: 'celery', q: 2, u: '' },
    { k: 'onion', q: 1, u: '', n: 'onion' },
    { k: 'garlic', q: 3, u: 'clove' },
    { k: 'stock', q: 1.5, u: 'l', n: 'stock' },
    { k: 'cumin', q: 1, u: 'tsp' },
    { k: 'lemon', q: 1, u: '' },
    { k: 'olive oil', q: 2, u: 'tbsp', pantry: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Dice the onion, carrot and celery. Cook in the olive oil for 6 min until soft.',
    'Add the garlic and cumin for 1 min, then the lentils and stock.',
    'Simmer for 20 min until the lentils are tender. Add water if it gets too thick.',
    'Blend half the soup with a stick blender, or mash a few ladlefuls against the pot. This makes it creamy without cream.',
    'Stir in the lemon juice, season, and serve with bread.'
  ],
  tip: 'Lentils need more salt than you think. Season, taste, then season again — it is the difference between flat and delicious.'
},
{
  id: 'stuffed-sweet-potato',
  title: 'Loaded Sweet Potatoes',
  blurb: 'Roasted until caramelised, stuffed with beans, cheese and salsa.',
  cat: 'veg', serves: 2, time: 40,
  tags: ['vegetarian', 'comfort'],
  ing: [
    { k: 'sweet potato', q: 2, u: '', n: 'sweet potatoes' },
    { k: 'beans', q: 400, u: 'g', n: 'black beans' },
    { k: 'cheese', q: 60, u: 'g', n: 'cheese, grated' },
    { k: 'salsa', q: 4, u: 'tbsp' },
    { k: 'yogurt', q: 0.33, u: 'cup', n: 'yogurt', opt: true },
    { k: 'olive oil', q: 1, u: 'tbsp', pantry: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Heat the oven to 220°C. Prick the sweet potatoes all over with a fork.',
    'Rub with olive oil and salt, put on a tray, and roast for 35 min until a knife slides in easily.',
    'Warm the drained beans with the salsa in a small pan for 3 min.',
    'Split the potatoes, fluff the insides with a fork, and pile in the beans and cheese.',
    'Return to the oven for 3 min to melt the cheese. Top with yogurt.'
  ],
  tip: 'In a hurry? Microwave the potatoes for 8 min, then roast for 15 to get caramelised edges.'
}
);
