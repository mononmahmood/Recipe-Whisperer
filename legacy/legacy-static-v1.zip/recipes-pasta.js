/* ---------------- PASTA ---------------- */
RECIPES.push(
{
  id: 'aglio-e-olio',
  title: 'Spaghetti Aglio e Olio',
  blurb: 'Garlic, olive oil, chilli. The pasta you make when the fridge is nearly empty.',
  cat: 'pasta', serves: 2, time: 20,
  tags: ['vegetarian', 'quick'],
  ing: [
    { k: 'pasta', q: 200, u: 'g', n: 'spaghetti' },
    { k: 'garlic', q: 5, u: 'clove' },
    { k: 'olive oil', q: 5, u: 'tbsp', pantry: true },
    { k: 'chili flakes', q: 0.5, u: 'tsp' },
    { k: 'parsley', q: 1, u: 'handful', opt: true },
    { k: 'cheese', q: 30, u: 'g', n: 'parmesan', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Boil the pasta in well-salted water. Scoop out a mug of pasta water before draining.',
    'While it cooks, slice the garlic thinly. Warm the olive oil in a wide pan over low heat and add the garlic and chilli flakes.',
    'Cook gently for 2–3 min until the garlic is pale gold. Do not let it brown — burnt garlic is bitter.',
    'Add the drained pasta and a splash of pasta water. Toss hard for 1 min until glossy and coated.',
    'Finish with chopped parsley and parmesan if you have it.'
  ],
  tip: 'The pasta water is the sauce. Starchy, salty water emulsifies with the oil so it clings instead of pooling.'
},
{
  id: 'cacio-e-pepe',
  title: 'Cacio e Pepe',
  blurb: 'Three ingredients, restaurant magic. Cheese, pepper, pasta water.',
  cat: 'pasta', serves: 2, time: 15,
  tags: ['vegetarian', 'quick'],
  ing: [
    { k: 'pasta', q: 200, u: 'g', n: 'spaghetti or tonnarelli' },
    { k: 'cheese', q: 80, u: 'g', n: 'pecorino or parmesan, finely grated' },
    { k: 'butter', q: 1, u: 'tbsp' },
    { k: 'black pepper', q: 1.5, u: 'tsp', pantry: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Boil the pasta in salted water. Before draining, scoop out 2 mugs of pasta water.',
    'Toast the black pepper in a dry pan for 30 sec until fragrant, then add the butter and 2 tbsp pasta water.',
    'Put the finely grated cheese in a bowl and whisk in 3 tbsp warm (not boiling) pasta water to make a smooth paste.',
    'Add the drained pasta to the pan off the heat, then stir in the cheese paste with a splash more water.',
    'Toss continuously until silky. Serve immediately with more pepper.'
  ],
  tip: 'Heat is the enemy at the end. If the cheese clumps, the pan was too hot — add a splash of cool pasta water and keep tossing.'
},
{
  id: 'tomato-garlic-pasta',
  title: 'Tomato & Garlic Pasta',
  blurb: 'A 25-minute pantry pasta with a sauce that tastes slow-cooked.',
  cat: 'pasta', serves: 2, time: 25,
  tags: ['vegetarian'],
  ing: [
    { k: 'pasta', q: 200, u: 'g' },
    { k: 'tomato-canned', q: 400, u: 'g', n: 'canned tomatoes' },
    { k: 'garlic', q: 4, u: 'clove' },
    { k: 'olive oil', q: 3, u: 'tbsp', pantry: true },
    { k: 'basil', q: 1, u: 'handful', opt: true },
    { k: 'cheese', q: 30, u: 'g', n: 'parmesan', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Get the pasta water boiling and salt it well.',
    'Warm the olive oil in a wide pan. Add sliced garlic and cook gently for 2 min, until fragrant and barely golden.',
    'Add the tomatoes, a pinch of salt, and simmer for 12 min, crushing the tomatoes with a spoon. It should look glossy and thick.',
    'Cook the pasta until just shy of al dente, then finish it in the sauce with a splash of pasta water for 1 min.',
    'Tear over basil, add parmesan, and grind on pepper.'
  ],
  tip: 'A pinch of sugar tames a sharp canned tomato. Add it with the salt, then taste before serving.'
},
{
  id: 'creamy-mushroom-pasta',
  title: 'Creamy Mushroom Pasta',
  blurb: 'Golden mushrooms, garlic cream, lots of black pepper. Deeply comforting.',
  cat: 'pasta', serves: 2, time: 25,
  tags: ['vegetarian'],
  ing: [
    { k: 'pasta', q: 200, u: 'g', n: 'tagliatelle or penne' },
    { k: 'mushroom', q: 250, u: 'g', n: 'mushrooms' },
    { k: 'cream', q: 150, u: 'ml', n: 'cream' },
    { k: 'garlic', q: 3, u: 'clove' },
    { k: 'cheese', q: 40, u: 'g', n: 'parmesan', opt: true },
    { k: 'butter', q: 1, u: 'tbsp' },
    { k: 'olive oil', q: 1, u: 'tbsp', pantry: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Boil the pasta in salted water.',
    'Slice the mushrooms thickly. Heat the olive oil and butter in a large pan over high heat and add the mushrooms in one layer.',
    'Leave them alone for 2 min, then toss and cook 3 min more until browned. Season now, not earlier.',
    'Lower the heat, add the garlic for 30 sec, then pour in the cream and simmer for 2 min.',
    'Add the drained pasta plus a splash of pasta water. Toss for 1 min, then finish with parmesan and lots of black pepper.'
  ],
  tip: 'Crowding the pan steams mushrooms instead of browning them. Use the biggest pan you own, or cook them in two batches.'
},
{
  id: 'pesto-pasta',
  title: 'Pesto Pasta with Blistered Tomatoes',
  blurb: 'Fifteen minutes, one pot, and it tastes like summer.',
  cat: 'pasta', serves: 2, time: 15,
  tags: ['vegetarian', 'quick'],
  ing: [
    { k: 'pasta', q: 200, u: 'g' },
    { k: 'pesto', q: 4, u: 'tbsp' },
    { k: 'tomato', q: 150, u: 'g', n: 'cherry tomatoes' },
    { k: 'cheese', q: 30, u: 'g', n: 'parmesan', opt: true },
    { k: 'olive oil', q: 1, u: 'tbsp', pantry: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Boil the pasta in salted water.',
    'Halve the tomatoes. Heat the olive oil in a small pan over high heat and add the tomatoes cut-side down. Cook for 3 min until blistered, then season.',
    'Drain the pasta, keeping a splash of water. Return it to the pot off the heat.',
    'Stir in the pesto and a splash of pasta water until glossy, then fold through the tomatoes.',
    'Finish with parmesan.'
  ],
  tip: 'Never heat pesto directly in a pan — the basil goes dull. Stir it into off-heat pasta instead.'
},
{
  id: 'lemon-chicken-orzo',
  title: 'One-Pan Lemon Chicken Orzo',
  blurb: 'Creamy orzo, golden chicken, bright lemon. A weeknight hero in one pan.',
  cat: 'pasta', serves: 4, time: 35,
  tags: ['high-protein', 'one-pan'],
  ing: [
    { k: 'chicken', q: 500, u: 'g', n: 'chicken thighs, diced' },
    { k: 'pasta', q: 300, u: 'g', n: 'orzo' },
    { k: 'stock', q: 700, u: 'ml' },
    { k: 'lemon', q: 1, u: '' },
    { k: 'spinach', q: 100, u: 'g', n: 'spinach' },
    { k: 'garlic', q: 3, u: 'clove' },
    { k: 'olive oil', q: 2, u: 'tbsp', pantry: true },
    { k: 'cheese', q: 40, u: 'g', n: 'parmesan', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Season the chicken with salt and pepper. Heat the olive oil in a deep pan and brown the chicken for 5 min. Set aside.',
    'Add the garlic and orzo to the pan and stir for 1 min to toast the pasta.',
    'Pour in the stock, add the lemon zest and half the juice, and bring to a simmer.',
    'Return the chicken, cover, and cook on low for 12 min, stirring twice so the orzo does not stick.',
    'Stir in the spinach and parmesan. Taste, add the rest of the lemon if it needs lift, and rest 2 min before serving.'
  ],
  tip: 'Orzo keeps drinking liquid as it sits. If it looks stiff at the end, loosen with a splash of hot stock or water.'
},
{
  id: 'pasta-e-ceci',
  title: 'Pasta e Ceci',
  blurb: 'Chickpea and tomato pasta. Hearty, cheap, and better on day two.',
  cat: 'pasta', serves: 3, time: 30,
  tags: ['vegetarian', 'comfort'],
  ing: [
    { k: 'pasta', q: 200, u: 'g', n: 'small pasta' },
    { k: 'chickpea', q: 400, u: 'g', n: 'canned chickpeas' },
    { k: 'tomato-canned', q: 400, u: 'g', n: 'canned tomatoes' },
    { k: 'garlic', q: 3, u: 'clove' },
    { k: 'olive oil', q: 3, u: 'tbsp', pantry: true },
    { k: 'rosemary', q: 1, u: 'sprig', opt: true },
    { k: 'cheese', q: 30, u: 'g', n: 'parmesan', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Warm the olive oil in a pot and cook the sliced garlic for 2 min.',
    'Add the tomatoes and rosemary, season, and simmer for 10 min.',
    'Add the chickpeas with half their liquid and 400 ml water. Simmer 5 min, then crush about a third of the chickpeas against the side of the pot to thicken the sauce.',
    'Add the pasta and cook in the sauce for 8–10 min, adding a splash of water if it gets thick.',
    'Taste for salt, grind over pepper, and finish with parmesan and a drizzle of olive oil.'
  ],
  tip: 'Crushing some chickpeas is what makes it creamy without cream. A potato masher works perfectly.'
},
{
  id: 'weeknight-bolognese',
  title: 'Weeknight Bolognese',
  blurb: 'A rich meat sauce in 45 minutes. Make double and freeze half.',
  cat: 'pasta', serves: 4, time: 45,
  tags: ['high-protein', 'comfort'],
  ing: [
    { k: 'beef', q: 500, u: 'g', n: 'ground beef' },
    { k: 'tomato-canned', q: 800, u: 'g', n: 'canned tomatoes' },
    { k: 'onion', q: 1, u: '', n: 'onion' },
    { k: 'carrot', q: 1, u: '' },
    { k: 'garlic', q: 3, u: 'clove' },
    { k: 'pasta', q: 350, u: 'g' },
    { k: 'olive oil', q: 2, u: 'tbsp', pantry: true },
    { k: 'cheese', q: 40, u: 'g', n: 'parmesan', opt: true },
    { k: 'salt', q: 1, u: 'pinch', pantry: true },
    { k: 'black pepper', q: 1, u: 'pinch', pantry: true }
  ],
  steps: [
    'Finely chop the onion and carrot. Warm the olive oil in a heavy pot and cook them for 6 min until soft.',
    'Add the garlic for 30 sec, then the beef. Break it up and cook over high heat until browned, about 5 min.',
    'Pour in the tomatoes, season well, and add a splash of water. Simmer uncovered for 25 min, stirring now and then.',
    'Cook the pasta in salted water for the last 10 min.',
    'Toss the pasta with the sauce and a splash of pasta water. Serve with parmesan.'
  ],
  tip: 'Brown the beef properly before adding tomatoes — that crust is where the flavour lives. Do not stir it constantly.'
}
);
